from fastapi.testclient import TestClient
from app.main import app

MASTER = {
    "summary": "Bilingual banking professional focused on fraud prevention.",
    "experience": [
        {"company": "Big Bank", "title": "Fraud Advisor", "start": "2021", "end": "2024", "bullets": [
            {"id": "f1", "text": "Investigated AML and KYC escalations for retail banking clients."},
            {"id": "f2", "text": "Handled bilingual client calls in English and French."},
        ]},
    ],
    "skills": [{"id": "s1", "name": "AML"}, {"id": "s2", "name": "KYC"}],
    "education": [{"id": "e1", "text": "Computer Engineering Technology, La Cite"}],
    "certifications": [],
    "languages": [{"id": "l1", "text": "English and French, professional fluency"}],
}

PROFILE = {"fields": [
    {"key": "preferred_name", "value": "M. Alem", "verification": "verified",
     "automation_may_submit": True, "requires_manual_approval": False},
    {"key": "email", "value": "me@example.com", "verification": "verified",
     "automation_may_submit": True, "requires_manual_approval": False},
    {"key": "work_authorization", "value": "Yes", "verification": "verified",
     "automation_may_submit": True, "requires_manual_approval": False},
]}


def job_payload(external_id="1"):
    return {"source": "greenhouse", "external_id": external_id, "title": "Bilingual Fraud Analyst",
            "company": "Example Bank", "location": "Ottawa", "apply_url": f"https://x.example/{external_id}",
            "description": "AML KYC banking fraud investigation compliance bilingual french"}


def test_full_pipeline_dry_run_and_manual_confirmation(tmp_path, monkeypatch):
    monkeypatch.setenv("JOBSNIFFING_DB", str(tmp_path / "test.sqlite3"))
    monkeypatch.delenv("JOBSNIFFING_ALLOW_LIVE_SUBMISSION", raising=False)
    with TestClient(app) as client:
        assert client.get("/api/mode").json()["mode"] == "discovery_only"
        automation = {"mode": "autonomous", "autonomy_companies": ["*"], "autonomy_min_score": 0}
        assert client.put("/api/settings/automation", json=automation).status_code == 200
        assert client.put("/api/profile", json=PROFILE).status_code == 200
        assert client.put("/api/documents/master", json={"content": MASTER}).status_code == 200

        job_id = client.post("/api/jobs", json=job_payload()).json()["id"]
        assert client.post(f"/api/jobs/{job_id}/status", json={"status": "shortlisted"}).status_code == 200

        docs = client.post(f"/api/jobs/{job_id}/documents").json()
        assert docs["status"] == "documents_prepared" and docs["factuality"]["lines_without_source"] == []
        assert docs["resume_pdf"].endswith(".pdf")

        answers = client.post(f"/api/jobs/{job_id}/answers",
                              json={"questions": ["Are you legally entitled to work in Canada?"]}).json()
        assert answers == {"status": "answers_prepared",
                           "counts": {"total": 1, "safe_auto": 1, "adapter_rule": 0, "requires_review": 0}}
        for status in ("ready_for_review", "approved"):
            assert client.post(f"/api/jobs/{job_id}/status", json={"status": status}).status_code == 200

        gates = client.get(f"/api/jobs/{job_id}/gates").json()
        assert gates["passed"] is True and len(gates["checks"]) == 9

        result = client.post(f"/api/jobs/{job_id}/submit",
                             json={"adapter": "email", "to_email": "hr@example.com"}).json()
        assert result["executed"] is True and result["result"] == "manual_intervention"
        assert result["status"] == "manual_intervention_required"
        kinds = {row["kind"] for row in client.get(f"/api/jobs/{job_id}/evidence").json()}
        assert "email_draft" in kinds

        confirm = client.post(f"/api/jobs/{job_id}/status",
                              json={"status": "submitted", "evidence": "Sent manually, confirmation #GH-123"})
        assert confirm.status_code == 200
        audit = client.get(f"/api/jobs/{job_id}/audit").json()
        assert audit["job"]["status"] == "submitted" and audit["job"]["submitted_at"]
        assert any(row["kind"] == "manual_confirmation" for row in audit["evidence"])

        export = client.get("/api/export.json").json()
        assert export["mode"] == "autonomous" and export["jobs"][0]["job"]["id"] == job_id


def test_gate_blocked_submit_and_evidence_rule(tmp_path, monkeypatch):
    monkeypatch.setenv("JOBSNIFFING_DB", str(tmp_path / "test.sqlite3"))
    with TestClient(app) as client:
        job_id = client.post("/api/jobs", json=job_payload("2")).json()["id"]
        for status in ("shortlisted", "approved"):
            assert client.post(f"/api/jobs/{job_id}/status", json={"status": status}).status_code == 200
        result = client.post(f"/api/jobs/{job_id}/submit", json={"adapter": "email"}).json()
        assert result["executed"] is False
        assert {"mode_autonomous", "documents_factual", "answers_ready"} <= set(result["blocking_gates"])
        assert client.get(f"/api/jobs/{job_id}").json()["status"] == "approved"

        assert client.post(f"/api/jobs/{job_id}/status", json={"status": "queued"}).status_code == 200
        assert client.post(f"/api/jobs/{job_id}/status", json={"status": "filling"}).status_code == 200
        no_evidence = client.post(f"/api/jobs/{job_id}/status", json={"status": "submitted"})
        assert no_evidence.status_code == 409 and "evidence" in no_evidence.json()["detail"]


def test_mode_switch_and_sensitive_profile_lockdown(tmp_path, monkeypatch):
    monkeypatch.setenv("JOBSNIFFING_DB", str(tmp_path / "test.sqlite3"))
    with TestClient(app) as client:
        assert client.put("/api/mode", json={"mode": "prepare_only"}).json()["mode"] == "prepare_only"
        assert client.get("/api/settings/automation").json()["mode"] == "prepare_only"
        assert client.put("/api/mode", json={"mode": "everything"}).status_code == 422

        fields = {"fields": [{"key": "salary_expectation", "value": "90k", "verification": "verified",
                              "automation_may_submit": True, "requires_manual_approval": False}]}
        stored = client.put("/api/profile", json=fields).json()["fields"][0]
        assert stored["automation_may_submit"] == 0 and stored["requires_manual_approval"] == 1
