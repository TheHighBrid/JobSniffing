from pathlib import Path
from app.adapters.submit.base import AdapterInput
from app.adapters.submit.greenhouse_playwright import _run_on_page

FORM_SELECTORS = {"#first_name", "#last_name", "#email", "#phone", "#resume", "#submit_app"}


class FakeLocator:
    def __init__(self, page, selector):
        self.page, self.selector = page, selector
    @property
    def first(self):
        return self
    def count(self):
        return 1 if self.selector in self.page.present else 0
    def fill(self, value):
        self.page.filled[self.selector] = value
    def set_input_files(self, path):
        self.page.files[self.selector] = path
    def click(self):
        self.page.phase = "after"


class FakePage:
    frames: list = []
    main_frame = None
    url = "https://boards.greenhouse.io/example/jobs/1"

    def __init__(self, before="apply for this role", after="thank you for applying today.", present=None):
        self.before, self.after = before, after
        self.present = FORM_SELECTORS if present is None else present
        self.phase, self.filled, self.files = "before", {}, {}

    def locator(self, selector):
        return FakeLocator(self, selector)
    def content(self):
        return self.before if self.phase == "before" else self.after
    def wait_for_timeout(self, ms):
        pass
    def screenshot(self, path, full_page=True):
        Path(path).write_bytes(b"\x89PNG fake")


def ctx(tmp_path):
    pdf = tmp_path / "resume.pdf"; pdf.write_bytes(b"%PDF-1.4 fake")
    return AdapterInput(job={"id": 1, "apply_url": FakePage.url},
                        contact={"name": "Mohamed Alem", "email": "me@example.com", "phone": "613-555-0100"},
                        resume_pdf=str(pdf), cover_letter="Dear team")


def test_happy_path_confirms_with_evidence_and_screenshots(tmp_path):
    page = FakePage()
    outcome = _run_on_page(page, ctx(tmp_path), shots_dir=tmp_path / "shots")
    assert outcome.result == "submitted"
    kinds = dict(outcome.evidence)
    assert "thank you for applying" in kinds["confirmation_text"]
    assert kinds["final_url"] == FakePage.url
    assert page.filled["#first_name"] == "Mohamed" and page.filled["#last_name"] == "Alem"
    assert page.files["#resume"].endswith("resume.pdf")
    assert len(outcome.screenshots) == 2 and all(Path(p).exists() for p in outcome.screenshots)


def test_captcha_is_never_bypassed(tmp_path):
    page = FakePage(before="please verify you are human (recaptcha)")
    outcome = _run_on_page(page, ctx(tmp_path))
    assert outcome.result == "manual_intervention" and "anti-bot" in outcome.message
    assert page.filled == {}


def test_missing_form_or_email_field_goes_manual(tmp_path):
    no_form = FakePage(present=set())
    assert _run_on_page(no_form, ctx(tmp_path)).result == "manual_intervention"
    no_email_value = ctx(tmp_path); no_email_value.contact.pop("email")
    assert _run_on_page(FakePage(), no_email_value).result == "manual_intervention"


def test_no_confirmation_text_stays_awaiting(tmp_path):
    page = FakePage(after="your submission is being processed")
    outcome = _run_on_page(page, ctx(tmp_path))
    assert outcome.result == "awaiting_confirmation"


def test_required_field_error_after_submit_goes_manual(tmp_path):
    page = FakePage(after="the field 'work eligibility' is required")
    outcome = _run_on_page(page, ctx(tmp_path))
    assert outcome.result == "manual_intervention"
