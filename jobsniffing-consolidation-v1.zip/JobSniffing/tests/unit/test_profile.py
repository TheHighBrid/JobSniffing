import pytest
from app.db.sqlite import init_db, session
from app.services.profile_service import get_field, is_sensitive_key, resolve_for_automation, upsert_field


def test_unknown_stays_unknown(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        value, reason = resolve_for_automation(conn, "languages", "application")
        assert value is None and "unknown" in reason


def test_sensitive_keys_are_locked_regardless_of_flags(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        upsert_field(conn, "salary_expectation", "negotiable", verification="verified",
                     automation_may_submit=True, requires_manual_approval=False)
        field = get_field(conn, "salary_expectation")
        assert field["automation_may_submit"] == 0 and field["requires_manual_approval"] == 1
        value, reason = resolve_for_automation(conn, "salary_expectation", "application")
        assert value is None and "manual approval" in reason
    assert is_sensitive_key("criminal_history") and not is_sensitive_key("work_authorization")


def test_verified_and_permitted_field_resolves(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        upsert_field(conn, "work_authorization", "Yes", verification="verified",
                     automation_may_submit=True, requires_manual_approval=False)
        value, source = resolve_for_automation(conn, "work_authorization", "application")
        assert value == "Yes" and source == "profile:work_authorization"


def test_unverified_or_wrong_context_is_refused(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        upsert_field(conn, "phone", "613-555-0100", verification="unverified",
                     automation_may_submit=True, requires_manual_approval=False)
        assert resolve_for_automation(conn, "phone", "application")[0] is None
        upsert_field(conn, "phone", "613-555-0100", verification="verified",
                     allowed_contexts=["documents"], automation_may_submit=True, requires_manual_approval=False)
        assert resolve_for_automation(conn, "phone", "application")[0] is None
        with pytest.raises(ValueError):
            upsert_field(conn, "x", "y", verification="maybe")
