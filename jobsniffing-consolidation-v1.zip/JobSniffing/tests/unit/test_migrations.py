import sqlite3
from app.db.sqlite import LATEST_SCHEMA_VERSION, SCHEMA, connect, init_db, session


def table_names(conn):
    return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def test_fresh_database_is_at_latest_version(tmp_path):
    path = tmp_path / "fresh.sqlite3"; init_db(path)
    with session(path) as conn:
        assert {"job_postings", "profile_fields", "qa_answers", "application_answers", "documents", "evidence"} <= table_names(conn)
        version = conn.execute("SELECT value FROM settings_kv WHERE key='_schema_version'").fetchone()[0]
        assert int(version) == LATEST_SCHEMA_VERSION
        cols = {r[1] for r in conn.execute("PRAGMA table_info(job_postings)")}
        assert "submitted_at" in cols


def test_legacy_v1_database_upgrades_and_preserves_rows(tmp_path):
    path = tmp_path / "legacy.sqlite3"
    conn = sqlite3.connect(path); conn.executescript(SCHEMA)
    conn.execute("INSERT INTO job_postings(source,external_id,title,company,apply_url) VALUES('manual','1','Fraud Analyst','Bank','https://x.example/1')")
    conn.commit(); conn.close()
    init_db(path)
    with session(path) as conn:
        assert "evidence" in table_names(conn)
        row = conn.execute("SELECT title, submitted_at FROM job_postings").fetchone()
        assert row["title"] == "Fraud Analyst" and row["submitted_at"] is None


def test_init_db_is_idempotent(tmp_path):
    path = tmp_path / "twice.sqlite3"
    init_db(path); init_db(path)
    with connect(path) as conn:
        assert int(conn.execute("SELECT value FROM settings_kv WHERE key='_schema_version'").fetchone()[0]) == LATEST_SCHEMA_VERSION
