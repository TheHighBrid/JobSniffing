from app.db.sqlite import init_db, session
from app.domain.enums import AnswerClassification as C
from app.services.gates import _answers_ready
from app.services.profile_service import DEMOGRAPHICS_POLICY_KEY, upsert_field
from app.services.question_engine import approve_answer, classify, prepare_answers, resolve
from app.services.tracking_service import upsert_job
from app.domain.schemas import JobPostingIn


def seed_job(conn):
    return upsert_job(conn, JobPostingIn(source="manual", external_id="1", title="Fraud Analyst",
                                         company="Bank", apply_url="https://x.example/1", description="aml"))


def test_sensitive_and_free_form_always_require_review():
    assert classify("What are your salary expectations?")[2] is C.REQUIRES_REVIEW
    assert classify("Have you ever been convicted of a criminal offence?")[2] is C.REQUIRES_REVIEW
    assert classify("Why do you want to work here?")[2] is C.REQUIRES_REVIEW


def test_known_profile_value_resolves_and_unknown_never_guesses(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        upsert_field(conn, "work_authorization", "Yes", verification="verified",
                     automation_may_submit=True, requires_manual_approval=False)
        resolved = resolve(conn, "Are you legally entitled to work in Canada?")
        assert resolved.answer == "Yes" and resolved.classification is C.SAFE_AUTO
        unknown = resolve(conn, "Which languages do you speak fluently?")
        assert unknown.classification is C.REQUIRES_REVIEW and unknown.answer == ""


def test_demographics_use_standing_policy_only_when_set(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        question = "How do you self-identify? (gender / visible minority / Indigenous)"
        assert resolve(conn, question).classification is C.REQUIRES_REVIEW
        upsert_field(conn, DEMOGRAPHICS_POLICY_KEY, "Prefer not to answer", verification="verified",
                     automation_may_submit=True, requires_manual_approval=False)
        resolved = resolve(conn, question)
        assert resolved.answer == "Prefer not to answer" and resolved.classification is C.ADAPTER_RULE


def test_qa_bank_fuzzy_reuse_for_unmapped_questions(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        conn.execute("INSERT INTO qa_answers(question,answer,classification,approved) VALUES(?,?,?,1)",
                     ("Do you own reliable transportation?", "Yes", "safe_auto"))
        resolved = resolve(conn, "Do you have reliable transportation?")
        assert resolved.answer == "Yes" and resolved.source.startswith("qa_bank:")


def test_prepare_and_approve_flow_clears_gate(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = seed_job(conn)
        upsert_field(conn, "work_authorization", "Yes", verification="verified",
                     automation_may_submit=True, requires_manual_approval=False)
        counts = prepare_answers(conn, job_id, [
            "Are you authorized to work in Canada?",
            "What are your salary expectations?",
        ])
        assert counts == {"total": 2, "safe_auto": 1, "adapter_rule": 0, "requires_review": 1}
        assert _answers_ready(conn, job_id)[0] is False
        approve_answer(conn, job_id, "What are your salary expectations?", "Aligned with the posted range", remember=True)
        assert _answers_ready(conn, job_id)[0] is True
        assert conn.execute("SELECT approved FROM qa_answers WHERE question LIKE 'What are your salary%'").fetchone()[0] == 1
