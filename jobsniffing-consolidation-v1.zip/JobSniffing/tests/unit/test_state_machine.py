import pytest
from app.domain.enums import ApplicationStatus as S
from app.domain.state_machine import ALLOWED_TRANSITIONS, assert_transition, can_transition, is_terminal


def test_safe_progression_and_noop():
    assert can_transition(S.SCORED, S.SHORTLISTED)
    assert can_transition(S.SCORED, S.SCORED)
    assert can_transition(S.FILLING, S.NEEDS_REVIEW)


def test_submitted_is_terminal():
    assert is_terminal(S.SUBMITTED)
    with pytest.raises(ValueError):
        assert_transition(S.SUBMITTED, S.FAILED)


def test_full_autonomous_pipeline_path_is_valid():
    path = [S.DISCOVERED, S.SCORED, S.SHORTLISTED, S.DOCUMENTS_PREPARED, S.ANSWERS_PREPARED,
            S.READY_FOR_REVIEW, S.APPROVED, S.QUEUED, S.FILLING, S.AWAITING_CONFIRMATION, S.SUBMITTED]
    for current, target in zip(path, path[1:]):
        assert_transition(current, target)


def test_failure_and_recovery_paths():
    assert can_transition(S.AWAITING_CONFIRMATION, S.VERIFICATION_FAILED)
    assert can_transition(S.VERIFICATION_FAILED, S.MANUAL_INTERVENTION_REQUIRED)
    assert can_transition(S.MANUAL_INTERVENTION_REQUIRED, S.QUEUED)
    assert can_transition(S.MANUAL_INTERVENTION_REQUIRED, S.SUBMITTED)
    assert can_transition(S.REJECTED, S.SHORTLISTED)


def test_no_shortcuts_into_submitted():
    allowed_sources = {c for c, targets in ALLOWED_TRANSITIONS.items() if S.SUBMITTED in targets}
    assert allowed_sources == {S.FILLING, S.AWAITING_CONFIRMATION, S.MANUAL_INTERVENTION_REQUIRED}


def test_every_status_has_transition_entry():
    assert set(ALLOWED_TRANSITIONS) == set(S)
    for terminal in (S.SUBMITTED, S.BLOCKED, S.WITHDRAWN, S.CLOSED):
        assert ALLOWED_TRANSITIONS[terminal] == set()
