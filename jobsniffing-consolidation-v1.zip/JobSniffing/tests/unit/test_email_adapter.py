import smtplib
from app.adapters.submit.base import AdapterInput
from app.adapters.submit.email_smtp import EmailSmtpAdapter


def ctx(tmp_path, **overrides):
    pdf = tmp_path / "resume.pdf"; pdf.write_bytes(b"%PDF-1.4 fake")
    defaults = dict(job={"title": "Fraud Analyst", "company": "Bank"}, contact={"name": "M. Alem"},
                    resume_pdf=str(pdf), cover_letter="Dear team", to_email="hr@example.com", live=False)
    defaults.update(overrides)
    return AdapterInput(**defaults)


def test_dry_run_prepares_but_never_sends(tmp_path, monkeypatch):
    called = []
    monkeypatch.setattr(smtplib, "SMTP", lambda *a, **k: called.append(a))
    outcome = EmailSmtpAdapter().run(ctx(tmp_path))
    assert outcome.result == "manual_intervention" and "not sent" in outcome.message.lower()
    assert outcome.evidence[0][0] == "email_draft" and not called


def test_env_gate_blocks_even_with_live_flag(tmp_path, monkeypatch):
    monkeypatch.delenv("JOBSNIFFING_ALLOW_LIVE_SUBMISSION", raising=False)
    outcome = EmailSmtpAdapter().run(ctx(tmp_path, live=True))
    assert outcome.result == "manual_intervention"


def test_missing_destination_or_resume_goes_manual(tmp_path):
    assert EmailSmtpAdapter().run(ctx(tmp_path, to_email=None)).result == "manual_intervention"
    assert EmailSmtpAdapter().run(ctx(tmp_path, resume_pdf="/nope.pdf")).result == "manual_intervention"


def test_live_send_records_message_id_evidence(tmp_path, monkeypatch):
    sent = {}

    class FakeSMTP:
        def __init__(self, host, port, timeout=30): sent["host"] = host
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def starttls(self): sent["tls"] = True
        def login(self, user, password): sent["user"] = user
        def send_message(self, message): sent["message_id"] = message["Message-ID"]

    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    for key, value in {"JOBSNIFFING_ALLOW_LIVE_SUBMISSION": "1", "SMTP_HOST": "smtp.example.com",
                       "SMTP_USERNAME": "u", "SMTP_PASSWORD": "p"}.items():
        monkeypatch.setenv(key, value)
    outcome = EmailSmtpAdapter().run(ctx(tmp_path, live=True))
    assert outcome.result == "submitted"
    kinds = dict(outcome.evidence)
    assert kinds["smtp_message_id"] == sent["message_id"] and "email_copy" in kinds


def test_smtp_failure_is_failed_not_submitted(tmp_path, monkeypatch):
    class Boom:
        def __init__(self, *a, **k): raise OSError("connection refused")
    monkeypatch.setattr(smtplib, "SMTP", Boom)
    for key, value in {"JOBSNIFFING_ALLOW_LIVE_SUBMISSION": "1", "SMTP_HOST": "smtp.example.com",
                       "SMTP_USERNAME": "u", "SMTP_PASSWORD": "p"}.items():
        monkeypatch.setenv(key, value)
    outcome = EmailSmtpAdapter().run(ctx(tmp_path, live=True))
    assert outcome.result == "failed" and "connection refused" in outcome.message
