import json
import pytest
from app.db.sqlite import init_db, session
from app.domain.schemas import JobPostingIn, ScoringSettings
from app.services import document_service as docs
from app.services.profile_service import upsert_field
from app.services.render_pdf import resume_pdf
from app.services.settings_service import save_scoring_settings
from app.services.tracking_service import upsert_job

MASTER = {
    "summary": "Bilingual banking professional focused on fraud prevention and client protection.",
    "experience": [
        {"company": "Big Bank", "title": "Fraud Advisor", "start": "2021", "end": "2024", "bullets": [
            {"id": "f1", "text": "Investigated AML and KYC escalations for retail banking clients."},
            {"id": "f2", "text": "Handled bilingual client calls in English and French."},
            {"id": "f3", "text": "Documented fraud cases in Excel with full audit notes."},
        ]},
    ],
    "skills": [{"id": "s1", "name": "AML"}, {"id": "s2", "name": "KYC"}, {"id": "s3", "name": "Excel"}],
    "education": [{"id": "e1", "text": "Computer Engineering Technology, La Cite"}],
    "certifications": [],
    "languages": [{"id": "l1", "text": "English and French, professional fluency"}],
}


def seed(conn, description="Seeking bilingual fraud analyst. AML and KYC experience required. SAS knowledge an asset. French an asset."):
    save_scoring_settings(conn, ScoringSettings(preferred_terms={"aml": 30, "kyc": 25, "bilingual": 20, "sas": 10}, excluded_terms=[], blacklisted_companies=[], minimum_score=0))
    docs.save_master(conn, MASTER)
    return upsert_job(conn, JobPostingIn(source="manual", external_id="1", title="Bilingual Fraud Analyst", company="Example Bank", apply_url="https://x.example/1", description=description))


def test_master_validation_rejects_missing_ids(tmp_path):
    init_db(tmp_path / "db.sqlite3")
    with session(tmp_path / "db.sqlite3") as conn:
        bad = json.loads(json.dumps(MASTER)); del bad["experience"][0]["bullets"][0]["id"]
        with pytest.raises(ValueError):
            docs.save_master(conn, bad)


def test_tailor_reorders_matches_and_passes_factuality(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = seed(conn)
        result = docs.tailor(conn, job_id)
        report, variant = result["factuality"], result["variant"]
        assert report["lines_without_source"] == []
        assert variant["experience"][0]["bullets"][0]["id"] == "f1"  # AML/KYC bullet first
        assert "aml" in report["keywords_matched"] and "bilingual" in report["keywords_matched"]
        assert any(k["keyword"] == "sas" for k in report["keywords_excluded"])  # JD wants SAS; no master evidence, so never claimed
        row = docs.latest_document(conn, job_id, docs.VARIANT_KIND)
        assert row["factuality_passed"] == 1 and report["doc_score"] >= 80


def test_forged_variant_fails_verification(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        seed(conn)
        forged = json.loads(json.dumps(MASTER))
        forged["experience"][0]["bullets"][0]["text"] = "Led a 50-person AML department."
        offenders = docs.verify_variant(docs.load_master(conn), forged)
        assert offenders and "50-person" in offenders[0]


def test_cover_letter_is_grounded_and_flags_unknown_name(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = seed(conn)
        result = docs.build_cover_letter(conn, job_id)
        assert "Example Bank" in result["text"] and "Bilingual Fraud Analyst" in result["text"]
        assert "Investigated AML" in result["text"]
        assert result["factuality_passed"] is False and result["factuality"]["placeholders"]
        upsert_field(conn, "preferred_name", "M. Alem", verification="verified", automation_may_submit=True, requires_manual_approval=False)
        again = docs.build_cover_letter(conn, job_id)
        assert again["factuality_passed"] is True and again["text"].rstrip().endswith("M. Alem")
        assert len(again["text"]) < 1300 and "passionate" not in again["text"].lower()


def test_resume_pdf_renders_single_page(tmp_path):
    out = tmp_path / "resume.pdf"
    pages = resume_pdf(MASTER, {"name": "Test Candidate", "email": "t@example.com", "location": "Ottawa, ON"}, out)
    assert out.exists() and out.read_bytes()[:5] == b"%PDF-" and pages == 1
