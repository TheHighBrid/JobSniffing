from app.db.sqlite import init_db, session
from app.domain.schemas import AutomationSettings, JobPostingIn
from app.services import gates
from app.services.settings_service import save_automation_settings
from app.services.tracking_service import upsert_job


def seed_ready_job(conn, external_id="1", company="Example Bank", title="Bilingual Fraud Investigator"):
    job_id = upsert_job(conn, JobPostingIn(source="greenhouse", external_id=external_id, title=title, company=company, location="Ottawa", apply_url=f"https://x.example/{external_id}", description="AML KYC banking fraud investigation compliance bilingual french"))
    conn.execute("INSERT INTO documents(job_id,kind,content,factuality_passed) VALUES(?,?,?,1)", (job_id, "resume_variant", "{}"))
    conn.execute("INSERT INTO documents(job_id,kind,content,factuality_passed) VALUES(?,?,?,1)", (job_id, "cover_letter", "{}"))
    conn.execute("INSERT INTO application_answers(job_id,question,answer,classification) VALUES(?,?,?,?)", (job_id, "Are you legally entitled to work in Canada?", "Yes", "safe_auto"))
    return job_id


def enable_autonomy(conn, **overrides):
    save_automation_settings(conn, AutomationSettings(mode="autonomous", autonomy_companies=["*"], **overrides))


def report_for(conn, job_id):
    job = conn.execute("SELECT * FROM job_postings WHERE id=?", (job_id,)).fetchone()
    return gates.evaluate(conn, job)


def failed_names(report):
    return {c.name for c in report.checks if not c.passed}


def test_all_gates_pass_for_ready_job(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = seed_ready_job(conn); enable_autonomy(conn)
        report = report_for(conn, job_id)
        assert report.passed, failed_names(report)
        assert len(report.checks) == 9


def test_mode_and_scope_gates_fail_closed(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = seed_ready_job(conn)
        save_automation_settings(conn, AutomationSettings(mode="prepare_only"))
        assert {"mode_autonomous", "autonomy_scope"} <= failed_names(report_for(conn, job_id))


def test_pending_review_answer_blocks_submission(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = seed_ready_job(conn); enable_autonomy(conn)
        conn.execute("INSERT INTO application_answers(job_id,question,answer,classification,approved) VALUES(?,?,?,?,0)", (job_id, "What are your salary expectations?", "", "requires_review"))
        assert "answers_ready" in failed_names(report_for(conn, job_id))


def test_duplicate_submission_and_daily_cap(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        first = seed_ready_job(conn, "1"); enable_autonomy(conn, max_submissions_per_day=1)
        conn.execute("UPDATE job_postings SET status='submitted', submitted_at=CURRENT_TIMESTAMP WHERE id=?", (first,))
        second = seed_ready_job(conn, "2")
        names = failed_names(report_for(conn, second))
        assert {"no_duplicate_submission", "daily_cap", "min_delay"} <= names


def test_missing_documents_block(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = upsert_job(conn, JobPostingIn(source="manual", external_id="9", title="Fraud Analyst", company="Bank", apply_url="https://x.example/9", description="aml kyc"))
        enable_autonomy(conn)
        assert "documents_factual" in failed_names(report_for(conn, job_id))
