import pytest
from app.adapters.submit.base import AdapterOutcome
from app.db.sqlite import init_db, session
from app.domain.enums import ApplicationStatus as S
from app.domain.schemas import AutomationSettings, JobPostingIn
from app.services import submission_service
from app.services.evidence_service import list_evidence
from app.services.settings_service import save_automation_settings
from app.services.tracking_service import change_status, get_job, upsert_job


class StubAdapter:
    name = "stub"
    def __init__(self, outcome): self.outcome = outcome
    def run(self, ctx): return self.outcome


def ready_job(conn, external_id="1"):
    job_id = upsert_job(conn, JobPostingIn(source="greenhouse", external_id=external_id, title="Fraud Analyst",
                                           company="Bank", apply_url=f"https://x.example/{external_id}",
                                           description="aml kyc bilingual banking fraud investigation compliance"))
    conn.execute("INSERT INTO documents(job_id,kind,content,factuality_passed) VALUES(?, 'resume_variant', '{}', 1)", (job_id,))
    conn.execute("INSERT INTO documents(job_id,kind,content,factuality_passed) VALUES(?, 'cover_letter', 'Dear team', 1)", (job_id,))
    conn.execute("INSERT INTO application_answers(job_id,question,answer,classification) VALUES(?, 'Authorized?', 'Yes', 'safe_auto')", (job_id,))
    save_automation_settings(conn, AutomationSettings(mode="autonomous", autonomy_companies=["*"], autonomy_min_score=0))
    for status in (S.SHORTLISTED, S.APPROVED):
        change_status(conn, job_id, status)
    return job_id


def run_with(conn, job_id, outcome, monkeypatch):
    monkeypatch.setitem(submission_service.ADAPTERS, "stub", StubAdapter(outcome))
    return submission_service.run_submission(conn, job_id, "stub", live=True)


def test_gate_block_leaves_status_untouched(tmp_path, monkeypatch):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = ready_job(conn)
        save_automation_settings(conn, AutomationSettings(mode="discovery_only"))
        result = submission_service.run_submission(conn, job_id, "email")
        assert result["executed"] is False and "mode_autonomous" in result["blocking_gates"]
        assert get_job(conn, job_id)["status"] == "approved"


def test_force_bypasses_policy_gates_only(tmp_path, monkeypatch):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = ready_job(conn)
        save_automation_settings(conn, AutomationSettings(mode="discovery_only"))
        outcome = AdapterOutcome("manual_intervention", "dry run")
        monkeypatch.setitem(submission_service.ADAPTERS, "stub", StubAdapter(outcome))
        result = submission_service.run_submission(conn, job_id, "stub", force=True)
        assert result["executed"] is True and result["status"] == "manual_intervention_required"


def test_confirmed_submission_reaches_submitted_with_evidence(tmp_path, monkeypatch):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = ready_job(conn)
        outcome = AdapterOutcome("submitted", "confirmed", evidence=[("confirmation_text", "thank you for applying")])
        result = run_with(conn, job_id, outcome, monkeypatch)
        job = get_job(conn, job_id)
        assert result["status"] == "submitted" and job["submitted_at"] is not None
        assert any(row["kind"] == "confirmation_text" for row in list_evidence(conn, job_id))


def test_success_claim_without_evidence_is_downgraded(tmp_path, monkeypatch):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = ready_job(conn)
        result = run_with(conn, job_id, AdapterOutcome("submitted", "trust me"), monkeypatch)
        assert result["status"] == "verification_failed"
        assert get_job(conn, job_id)["submitted_at"] is None


def test_wrong_starting_status_is_rejected(tmp_path):
    path = tmp_path / "db.sqlite3"; init_db(path)
    with session(path) as conn:
        job_id = upsert_job(conn, JobPostingIn(source="manual", external_id="9", title="X", company="Y",
                                               apply_url="https://x.example/9", description="aml"))
        with pytest.raises(ValueError, match="requires status"):
            submission_service.run_submission(conn, job_id, "email")
