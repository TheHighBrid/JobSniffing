# Consolidation Decision Record — consolidation-v1

**Date:** 2026-07-14 · **Decision owner:** Haiburidu · **Prepared by:** Claude (sprint session)

## Decision

**JobSniffing is the canonical repository.** JobTomatik and HunterXJob are archived.
The best organs of both were ported into JobSniffing on branch `consolidation-v1`
rather than merging histories, because JobSniffing already had the cleanest core
(strict state machine, 25 passing tests, Termux-first bootstrap, 5 dependencies)
and was itself a deliberate distillation of the other two (see `docs/audit.md`).

| Component | Origin | Disposition |
|---|---|---|
| Discovery (Greenhouse/Lever/Ashby), scoring, dashboard, verify.sh | JobSniffing | Kept as-is |
| State machine | JobSniffing | Extended to the full 19-state pipeline (superset; every 0.2.0 transition still valid) |
| Submission adapters (email SMTP, Greenhouse Playwright) | HunterXJob | Ported: fail-closed, confirmation-keyword evidence, CAPTCHA → human handoff |
| Safety caps / delays / blacklist | HunterXJob `safety.py` | Ported into the 9-check gate report |
| QA bank fuzzy matching | HunterXJob | Ported into the question engine (stdlib difflib, approved answers only) |
| Résumé rendering | HunterXJob (Jinja→Chromium PDF) | Replaced with ReportLab (no Chromium in the document path) |
| Capacitor APK shell docs | JobTomatik | Salvaged as roadmap notes only |
| Redis/Celery/Docker/Postgres/SendGrid/LLM-key runtime | JobTomatik | **Rejected** — violates the $0 Termux-first constraint |
| LinkedIn/Indeed/Upwork adapters | HunterXJob roadmap | **Rejected** — ToS/ban risk; kept permanently disabled |

## Safety invariants (enforced in code, covered by tests)

1. `submitted` is reachable only from `filling`, `awaiting_confirmation`, or
   `manual_intervention_required` (state-machine test) **and** only with
   confirmation-kind evidence recorded (`tracking_service` raises otherwise).
2. Adapters never return "submitted" without attaching evidence; the
   orchestrator downgrades any unevidenced success claim to `verification_failed`.
3. CAPTCHA / anti-bot detection always ends in `manual_intervention_required`.
   Never solved, never bypassed, never retried automatically.
4. Live sending requires the `JOBSNIFFING_ALLOW_LIVE_SUBMISSION=1` environment
   gate **and** `live=true` per call. The dashboard cannot flip the env gate.
5. Sensitive profile keys (salary, criminal, disability, demographics,
   clearance, conflicts, references, legal declarations) are structurally
   locked to manual approval; the question engine never answers from
   incomplete information — unknown stays unknown.
6. `force=true` (explicit human request) bypasses only mode/scope/score
   policy gates — never evidence, factuality, duplicate, cap, or delay gates.
7. Default mode is `discovery_only`; autonomy additionally requires per-company,
   per-ATS, or per-job opt-in (`autonomy_*` settings).

## Deltas from the original spec (with reasons)

- **Tiered submission**: Tier 0 email (Termux-native stdlib) → Tier 2
  Playwright as an opt-in `[automation]` extra inside the Ubuntu proot.
  Chromium is too heavy for bare Termux and unnecessary for the email channel.
- **PDFs via ReportLab**, not headless Chromium: ATS-safe single-column
  Helvetica output, renders on-device in milliseconds.
- **GC Jobs**: discovery + document prep + manual-submit checklist only.
  Automating authenticated government portals is out of scope by design.
- **Workday / SmartRecruiters / iCIMS / Taleo**: adapter interface is ready;
  implementations deferred until live postings are available to test against
  (fixtures alone proved unreliable in HunterXJob).

## Verification

`scripts/verify.sh` → 69 pytest tests + live server smoke (job create, default
`discovery_only` mode). Greenhouse adapter page-logic is tested against a fake
Page object; it has **not** been exercised against a live Chromium in this
environment (Playwright browser downloads are unavailable here) — treat the
live browser path as framework-complete but field-unverified.

## Archive instructions

1. Push this branch, open PR, merge to `main`.
2. GitHub → JobTomatik → Settings → Archive (read-only). Add a README banner
   pointing here. Same for HunterXJob after confirming nothing else is wanted.
