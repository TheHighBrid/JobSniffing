from __future__ import annotations

import csv
import io
import sqlite3
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.config import APP_VERSION, PROJECT_ROOT, get_db_path
from app.db.sqlite import init_db, session
from app.domain.enums import ApplicationStatus
from app.domain.schemas import (AnswerApproval, AnswersRequest, AutomationSettings, DiscoveryRequest, JobImportRequest, JobPostingIn, MasterResumeIn, ModeUpdate, ProfileUpdate, ScoringSettings, StatusChange, SubmitRequest)
from app.domain.state_machine import ALLOWED_TRANSITIONS
from app.services.discovery_service import DiscoveryError, discover
from app.services.settings_service import load_scoring_settings, save_scoring_settings
from app.services import document_service, gates, profile_service, question_engine, submission_service
from app.services.evidence_service import list_evidence
from app.services.settings_service import load_automation_settings, save_automation_settings
from app.services.tracking_service import bulk_upsert, change_status, delete_job, get_job, list_jobs, log_run, rescore_all, stats, upsert_job


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield


app = FastAPI(title="JobSniffing", version=APP_VERSION, lifespan=lifespan)
app.mount("/static", StaticFiles(directory=PROJECT_ROOT / "app/web/static"), name="static")
templates = Jinja2Templates(directory=PROJECT_ROOT / "app/web/templates")


def get_conn():
    init_db()
    with session() as conn:
        yield conn


def parse_optional_status(value: str | None) -> ApplicationStatus | None:
    """Treat a missing or blank query value as no status filter."""
    if value is None or not value.strip():
        return None
    try:
        return ApplicationStatus(value)
    except ValueError as exc:
        allowed = ", ".join(status.value for status in ApplicationStatus)
        raise HTTPException(422, f"Invalid status '{value}'. Expected one of: {allowed}") from exc


@app.get("/health")
def health(conn: sqlite3.Connection = Depends(get_conn)):
    return {"status": "ok", "version": APP_VERSION, "mode": "local-first", "automation": "manual-review-only", "database": str(get_db_path()), "jobs": stats(conn)["total"], "providers": ["greenhouse", "lever", "ashby"]}


@app.post("/api/jobs", status_code=201)
def create_job(job: JobPostingIn, conn: sqlite3.Connection = Depends(get_conn)):
    return {"id": upsert_job(conn, job)}


@app.post("/api/jobs/import", status_code=201)
def import_jobs(payload: JobImportRequest, conn: sqlite3.Connection = Depends(get_conn)):
    ids = bulk_upsert(conn, payload.jobs)
    log_run(conn, "import", f"Imported {len(ids)} jobs")
    return {"imported": len(ids), "ids": ids}


@app.get("/api/jobs")
def api_jobs(status_value: str | None = Query(None, alias="status"), q: str = Query("", max_length=200), min_score: int = Query(0, ge=0, le=100), limit: int = Query(250, ge=1, le=1000), conn: sqlite3.Connection = Depends(get_conn)):
    job_status = parse_optional_status(status_value)
    return [dict(row) for row in list_jobs(conn, status=job_status, query=q, min_score=min_score, limit=limit)]


@app.get("/api/jobs/export.csv")
def export_jobs(conn: sqlite3.Connection = Depends(get_conn)):
    output = io.StringIO()
    fields = ["id", "source", "external_id", "title", "company", "location", "apply_url", "score", "status", "notes", "created_at", "updated_at"]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for row in list_jobs(conn, limit=100000):
        writer.writerow(dict(row))
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=jobsniffing-export.csv"})


@app.get("/api/jobs/{job_id}")
def api_job(job_id: int, conn: sqlite3.Connection = Depends(get_conn)):
    row = get_job(conn, job_id)
    if row is None:
        raise HTTPException(404, f"Unknown job id {job_id}")
    return dict(row)


@app.delete("/api/jobs/{job_id}", status_code=204)
def api_delete(job_id: int, conn: sqlite3.Connection = Depends(get_conn)):
    if not delete_job(conn, job_id):
        raise HTTPException(404, f"Unknown job id {job_id}")
    return Response(status_code=204)


@app.post("/api/jobs/{job_id}/status")
def api_status(job_id: int, change: StatusChange, conn: sqlite3.Connection = Depends(get_conn)):
    try:
        change_status(conn, job_id, change.status, change.notes, evidence_text=change.evidence)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    return {"ok": True, "status": change.status.value}


@app.post("/api/discovery")
def api_discovery(request: DiscoveryRequest, conn: sqlite3.Connection = Depends(get_conn)):
    try:
        jobs = discover(request)
    except DiscoveryError as exc:
        raise HTTPException(502, str(exc)) from exc
    ids = bulk_upsert(conn, jobs)
    log_run(conn, "discovery", f"{request.provider}:{request.identifier} stored {len(ids)} jobs")
    return {"provider": request.provider, "identifier": request.identifier, "discovered": len(jobs), "stored": len(ids), "ids": ids}


@app.get("/api/settings/scoring", response_model=ScoringSettings)
def get_settings(conn: sqlite3.Connection = Depends(get_conn)):
    return load_scoring_settings(conn)


@app.put("/api/settings/scoring", response_model=ScoringSettings)
def put_settings(settings: ScoringSettings, conn: sqlite3.Connection = Depends(get_conn)):
    save_scoring_settings(conn, settings)
    rescore_all(conn, settings)
    return settings


@app.post("/api/jobs/rescore")
def rescore(conn: sqlite3.Connection = Depends(get_conn)):
    return {"rescored": rescore_all(conn)}


@app.get("/api/stats")
def api_stats(conn: sqlite3.Connection = Depends(get_conn)):
    return stats(conn)




def _job_or_404(conn: sqlite3.Connection, job_id: int) -> sqlite3.Row:
    row = get_job(conn, job_id)
    if row is None:
        raise HTTPException(404, f"Unknown job id {job_id}")
    return row


@app.get("/api/mode")
def get_mode(conn: sqlite3.Connection = Depends(get_conn)):
    settings = load_automation_settings(conn)
    return {"mode": settings.mode, "settings": settings.model_dump()}


@app.put("/api/mode")
def put_mode(update: ModeUpdate, conn: sqlite3.Connection = Depends(get_conn)):
    settings = load_automation_settings(conn)
    settings.mode = update.mode
    save_automation_settings(conn, settings)
    log_run(conn, "mode", f"automation mode set to {update.mode}")
    return {"mode": settings.mode, "settings": settings.model_dump()}


@app.get("/api/settings/automation", response_model=AutomationSettings)
def get_automation_settings(conn: sqlite3.Connection = Depends(get_conn)):
    return load_automation_settings(conn)


@app.put("/api/settings/automation", response_model=AutomationSettings)
def put_automation_settings(settings: AutomationSettings, conn: sqlite3.Connection = Depends(get_conn)):
    save_automation_settings(conn, settings)
    log_run(conn, "mode", f"automation settings updated (mode={settings.mode})")
    return settings


@app.get("/api/jobs/{job_id}/gates")
def api_gates(job_id: int, conn: sqlite3.Connection = Depends(get_conn)):
    return gates.evaluate(conn, _job_or_404(conn, job_id)).to_dict()


@app.get("/api/profile")
def get_profile(conn: sqlite3.Connection = Depends(get_conn)):
    return {"fields": profile_service.list_fields(conn)}


@app.put("/api/profile")
def put_profile(update: ProfileUpdate, conn: sqlite3.Connection = Depends(get_conn)):
    for field in update.fields:
        profile_service.upsert_field(
            conn, field.key, field.value, source=field.source, verification=field.verification,
            allowed_contexts=field.allowed_contexts, automation_may_submit=field.automation_may_submit,
            requires_manual_approval=field.requires_manual_approval,
        )
    return {"fields": profile_service.list_fields(conn)}


@app.put("/api/documents/master")
def put_master(payload: MasterResumeIn, conn: sqlite3.Connection = Depends(get_conn)):
    try:
        version = document_service.save_master(conn, payload.content)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return {"kind": document_service.MASTER_KIND, "version": version}


@app.get("/api/documents/master")
def get_master(conn: sqlite3.Connection = Depends(get_conn)):
    master = document_service.load_master(conn)
    if master is None:
        raise HTTPException(404, "No master resume stored")
    return {"content": master}


@app.post("/api/jobs/{job_id}/documents")
def prepare_documents(job_id: int, conn: sqlite3.Connection = Depends(get_conn)):
    job = _job_or_404(conn, job_id)
    try:
        tailored = document_service.tailor(conn, job_id)
        cover = document_service.build_cover_letter(conn, job_id)
        pdf_path = document_service.ensure_variant_pdf(conn, job_id)
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    status = ApplicationStatus(job["status"])
    if status is ApplicationStatus.SHORTLISTED:
        change_status(conn, job_id, ApplicationStatus.DOCUMENTS_PREPARED, notes="documents pipeline completed")
        status = ApplicationStatus.DOCUMENTS_PREPARED
    log_run(conn, "documents", f"job {job_id}: resume v{tailored['version']} + cover v{cover['version']} prepared")
    return {
        "status": status.value, "resume_version": tailored["version"], "cover_version": cover["version"],
        "resume_pdf": pdf_path, "factuality": tailored["factuality"],
        "cover_factuality_passed": cover["factuality_passed"],
    }


@app.post("/api/jobs/{job_id}/answers")
def prepare_job_answers(job_id: int, payload: AnswersRequest, conn: sqlite3.Connection = Depends(get_conn)):
    job = _job_or_404(conn, job_id)
    counts = question_engine.prepare_answers(conn, job_id, payload.questions)
    status = ApplicationStatus(job["status"])
    if counts["requires_review"] == 0 and status is ApplicationStatus.DOCUMENTS_PREPARED:
        change_status(conn, job_id, ApplicationStatus.ANSWERS_PREPARED, notes="all answers resolved from approved sources")
        status = ApplicationStatus.ANSWERS_PREPARED
    return {"status": status.value, "counts": counts}


@app.get("/api/jobs/{job_id}/answers")
def get_job_answers(job_id: int, conn: sqlite3.Connection = Depends(get_conn)):
    _job_or_404(conn, job_id)
    return [dict(row) for row in question_engine.list_answers(conn, job_id)]


@app.post("/api/jobs/{job_id}/answers/approve")
def approve_job_answer(job_id: int, payload: AnswerApproval, conn: sqlite3.Connection = Depends(get_conn)):
    _job_or_404(conn, job_id)
    try:
        question_engine.approve_answer(conn, job_id, payload.question, payload.answer, remember=payload.remember)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    from app.services.gates import _answers_ready
    ready, detail = _answers_ready(conn, job_id)
    return {"approved": True, "answers_ready": ready, "detail": detail}


@app.get("/api/jobs/{job_id}/evidence")
def api_evidence(job_id: int, conn: sqlite3.Connection = Depends(get_conn)):
    _job_or_404(conn, job_id)
    return [dict(row) for row in list_evidence(conn, job_id)]


def _audit_payload(conn: sqlite3.Connection, job: sqlite3.Row) -> dict:
    job_id = int(job["id"])
    documents = [
        {k: row[k] for k in ("id", "kind", "version", "pdf_path", "factuality_passed", "created_at")}
        | {"factuality": row["factuality"]}
        for row in conn.execute(
            "SELECT * FROM documents WHERE job_id=? ORDER BY kind, version", (job_id,)
        )
    ]
    return {
        "job": dict(job),
        "answers": [dict(r) for r in question_engine.list_answers(conn, job_id)],
        "documents": documents,
        "evidence": [dict(r) for r in list_evidence(conn, job_id)],
    }


@app.get("/api/jobs/{job_id}/audit")
def api_audit(job_id: int, conn: sqlite3.Connection = Depends(get_conn)):
    job = _job_or_404(conn, job_id)
    payload = _audit_payload(conn, job)
    payload["gates"] = gates.evaluate(conn, job).to_dict()
    return payload


@app.get("/api/export.json")
def export_json(conn: sqlite3.Connection = Depends(get_conn)):
    settings = load_automation_settings(conn)
    return {
        "mode": settings.mode,
        "stats": stats(conn),
        "jobs": [_audit_payload(conn, row) for row in list_jobs(conn, limit=100000)],
    }


@app.post("/api/jobs/{job_id}/submit")
def api_submit(job_id: int, payload: SubmitRequest, conn: sqlite3.Connection = Depends(get_conn)):
    _job_or_404(conn, job_id)
    try:
        return submission_service.run_submission(
            conn, job_id, payload.adapter, live=payload.live, to_email=payload.to_email, force=payload.force,
        )
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc


@app.get("/", response_class=HTMLResponse)
def index(request: Request, status_value: str | None = Query(None, alias="status"), q: str = Query("", max_length=200), min_score: int | None = Query(None, ge=0, le=100), conn: sqlite3.Connection = Depends(get_conn)):
    job_status = parse_optional_status(status_value)
    settings = load_scoring_settings(conn)
    resolved_min = settings.minimum_score if min_score is None else min_score
    transitions = {s.value: [t.value for t in sorted(targets, key=lambda item: item.value)] for s, targets in ALLOWED_TRANSITIONS.items()}
    return templates.TemplateResponse(request=request, name="index.html", context={"jobs": list_jobs(conn, status=job_status, query=q, min_score=resolved_min, limit=500), "stats": stats(conn), "statuses": list(ApplicationStatus), "selected_status": job_status.value if job_status else "", "query": q, "min_score": resolved_min, "transitions": transitions, "version": APP_VERSION})
