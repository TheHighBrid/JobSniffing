from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from app.config import get_db_path

SCHEMA = """
CREATE TABLE IF NOT EXISTS job_postings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,
  external_id TEXT NOT NULL,
  title TEXT NOT NULL,
  company TEXT NOT NULL,
  location TEXT NOT NULL DEFAULT '',
  apply_url TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  score INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'discovered',
  notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(source, external_id)
);
CREATE INDEX IF NOT EXISTS idx_job_score ON job_postings(score DESC);
CREATE INDEX IF NOT EXISTS idx_job_status ON job_postings(status);
CREATE TABLE IF NOT EXISTS answer_bank (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  question TEXT NOT NULL UNIQUE,
  answer TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS run_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings_kv (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

# Ordered, idempotent-by-version migrations. Version 1 is the 0.2.0 baseline
# (SCHEMA above). Each later version runs at most once per database.
MIGRATIONS: dict[int, str] = {
    2: """
    ALTER TABLE job_postings ADD COLUMN submitted_at TEXT;
    CREATE TABLE IF NOT EXISTS profile_fields (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      source TEXT NOT NULL DEFAULT '',
      verification TEXT NOT NULL DEFAULT 'unverified',
      allowed_contexts TEXT NOT NULL DEFAULT '[]',
      automation_may_submit INTEGER NOT NULL DEFAULT 0,
      requires_manual_approval INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS qa_answers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      question TEXT NOT NULL UNIQUE,
      answer TEXT NOT NULL,
      classification TEXT NOT NULL DEFAULT 'requires_review',
      approved INTEGER NOT NULL DEFAULT 0,
      usage_count INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS application_answers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id INTEGER NOT NULL REFERENCES job_postings(id) ON DELETE CASCADE,
      question TEXT NOT NULL,
      answer TEXT NOT NULL DEFAULT '',
      classification TEXT NOT NULL,
      source TEXT NOT NULL DEFAULT '',
      approved INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(job_id, question)
    );
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id INTEGER REFERENCES job_postings(id) ON DELETE CASCADE,
      kind TEXT NOT NULL,
      version INTEGER NOT NULL DEFAULT 1,
      content TEXT NOT NULL,
      pdf_path TEXT NOT NULL DEFAULT '',
      factuality TEXT NOT NULL DEFAULT '{}',
      factuality_passed INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_documents_job_kind ON documents(job_id, kind, version DESC);
    CREATE TABLE IF NOT EXISTS evidence (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id INTEGER NOT NULL REFERENCES job_postings(id) ON DELETE CASCADE,
      kind TEXT NOT NULL,
      content TEXT NOT NULL DEFAULT '',
      path TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_evidence_job ON evidence(job_id);
    """,
}

LATEST_SCHEMA_VERSION = max(MIGRATIONS) if MIGRATIONS else 1
_VERSION_KEY = "_schema_version"


def connect(path: Path | None = None) -> sqlite3.Connection:
    db_path = path or get_db_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def _schema_version(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT value FROM settings_kv WHERE key=?", (_VERSION_KEY,)).fetchone()
    return int(row["value"]) if row else 1


def _set_schema_version(conn: sqlite3.Connection, version: int) -> None:
    conn.execute(
        "INSERT INTO settings_kv(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP",
        (_VERSION_KEY, str(version)),
    )


def apply_migrations(conn: sqlite3.Connection) -> int:
    current = _schema_version(conn)
    for version in sorted(MIGRATIONS):
        if version <= current:
            continue
        conn.executescript(MIGRATIONS[version])
        _set_schema_version(conn, version)
        current = version
    conn.commit()
    return current


def init_db(path: Path | None = None) -> Path:
    db_path = path or get_db_path()
    with connect(db_path) as conn:
        conn.executescript(SCHEMA)
        apply_migrations(conn)
    return db_path


@contextmanager
def session(path: Path | None = None) -> Iterator[sqlite3.Connection]:
    conn = connect(path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
