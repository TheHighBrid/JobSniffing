"""ATS-safe PDF rendering with ReportLab.

Single column, standard Helvetica, no tables, no graphics — deliberately dull
so applicant-tracking parsers read it cleanly. Runs on Termux without
Chromium, which is the whole point.
"""
from __future__ import annotations

from pathlib import Path

from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

_BASE = dict(fontName="Helvetica", fontSize=10.5, leading=13.5, alignment=TA_LEFT)
STYLES = {
    "name": ParagraphStyle("name", fontName="Helvetica-Bold", fontSize=16, leading=19),
    "contact": ParagraphStyle("contact", **{**_BASE, "fontSize": 9.5}),
    "heading": ParagraphStyle("heading", fontName="Helvetica-Bold", fontSize=11.5, leading=14, spaceBefore=8),
    "role": ParagraphStyle("role", fontName="Helvetica-Bold", **{k: v for k, v in _BASE.items() if k != "fontName"}),
    "body": ParagraphStyle("body", **_BASE),
    "bullet": ParagraphStyle("bullet", leftIndent=14, bulletIndent=4, **_BASE),
}


def _escape(text: str) -> str:
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _doc(path: Path) -> SimpleDocTemplate:
    path.parent.mkdir(parents=True, exist_ok=True)
    return SimpleDocTemplate(
        str(path), pagesize=LETTER,
        leftMargin=0.7 * inch, rightMargin=0.7 * inch, topMargin=0.6 * inch, bottomMargin=0.6 * inch,
    )


def resume_pdf(variant: dict, contact: dict[str, str], out_path: Path) -> int:
    story = []
    if contact.get("name"):
        story.append(Paragraph(_escape(contact["name"]), STYLES["name"]))
    contact_line = " | ".join(
        _escape(contact[k]) for k in ("email", "phone", "location") if contact.get(k)
    )
    if contact_line:
        story.append(Paragraph(contact_line, STYLES["contact"]))
    if variant.get("summary"):
        story.append(Paragraph("Summary", STYLES["heading"]))
        story.append(Paragraph(_escape(variant["summary"]), STYLES["body"]))
    if variant.get("experience"):
        story.append(Paragraph("Experience", STYLES["heading"]))
        for role in variant["experience"]:
            dates = " – ".join(x for x in (role.get("start", ""), role.get("end", "")) if x)
            header = f"{role.get('title','')} — {role.get('company','')}" + (f" ({dates})" if dates else "")
            story.append(Paragraph(_escape(header), STYLES["role"]))
            for bullet in role.get("bullets", []):
                story.append(Paragraph(_escape(bullet["text"]), STYLES["bullet"], bulletText="•"))
            story.append(Spacer(1, 4))
    sections = (
        ("skills", "Skills", "name"), ("certifications", "Certifications", "text"),
        ("education", "Education", "text"), ("languages", "Languages", "text"),
    )
    for key, title, text_key in sections:
        items = variant.get(key, [])
        if not items:
            continue
        story.append(Paragraph(title, STYLES["heading"]))
        if key in ("skills", "languages"):
            story.append(Paragraph(_escape(", ".join(str(i[text_key]) for i in items)), STYLES["body"]))
        else:
            for item in items:
                story.append(Paragraph(_escape(item[text_key]), STYLES["bullet"], bulletText="•"))
    doc = _doc(out_path)
    doc.build(story)
    return int(doc.page)


def cover_letter_pdf(text: str, contact: dict[str, str], out_path: Path) -> int:
    story = []
    if contact.get("name"):
        story.append(Paragraph(_escape(contact["name"]), STYLES["name"]))
        story.append(Spacer(1, 10))
    for line in text.split("\n"):
        story.append(Paragraph(_escape(line) or "&nbsp;", STYLES["body"]))
    doc = _doc(out_path)
    doc.build(story)
    return int(doc.page)
