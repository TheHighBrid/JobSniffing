"""Submission gates.

Every gate must pass before an autonomous submission is allowed. The report is
returned whole so the dashboard can show exactly why an application is (or is
not) eligible, instead of a bare yes/no.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field

from app.domain.enums import AnswerClassification, AutomationMode
from app.services.settings_service import (
    is_blacklisted,
    load_automation_settings,
    load_scoring_settings,
)


@dataclass
class GateCheck:
    name: str
    passed: bool
    detail: str


@dataclass
class GateReport:
    passed: bool = False
    checks: list[GateCheck] = field(default_factory=list)

    def add(self, name: str, passed: bool, detail: str) -> None:
        self.checks.append(GateCheck(name, passed, detail))

    def finalize(self) -> "GateReport":
        self.passed = all(check.passed for check in self.checks)
        return self

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "checks": [check.__dict__ for check in self.checks],
        }


def _duplicate_submission_exists(conn: sqlite3.Connection, job: sqlite3.Row) -> bool:
    row = conn.execute(
        """
        SELECT 1 FROM job_postings
        WHERE id != ? AND status = 'submitted'
          AND (
            lower(company) = lower(?) AND lower(title) = lower(?)
            OR apply_url = ?
          )
        LIMIT 1
        """,
        (job["id"], job["company"], job["title"], job["apply_url"]),
    ).fetchone()
    return row is not None


def _documents_ready(conn: sqlite3.Connection, job_id: int) -> tuple[bool, str]:
    resume = conn.execute(
        "SELECT factuality_passed FROM documents WHERE job_id=? AND kind='resume_variant' ORDER BY version DESC LIMIT 1",
        (job_id,),
    ).fetchone()
    cover = conn.execute(
        "SELECT factuality_passed FROM documents WHERE job_id=? AND kind='cover_letter' ORDER BY version DESC LIMIT 1",
        (job_id,),
    ).fetchone()
    if resume is None or cover is None:
        return False, "tailored resume and cover letter are not both prepared"
    if not resume["factuality_passed"] or not cover["factuality_passed"]:
        return False, "latest documents did not pass the factuality check"
    return True, "resume and cover letter prepared and factual"


def _answers_ready(conn: sqlite3.Connection, job_id: int) -> tuple[bool, str]:
    total = conn.execute(
        "SELECT COUNT(*) FROM application_answers WHERE job_id=?", (job_id,)
    ).fetchone()[0]
    if total == 0:
        return False, "no application answers have been prepared"
    pending = conn.execute(
        "SELECT COUNT(*) FROM application_answers WHERE job_id=? AND classification=? AND approved=0",
        (job_id, AnswerClassification.REQUIRES_REVIEW.value),
    ).fetchone()[0]
    if pending:
        return False, f"{pending} answer(s) still require manual review"
    return True, f"{total} answers ready, none pending review"


def _within_daily_cap(conn: sqlite3.Connection, cap: int) -> tuple[bool, str]:
    count = conn.execute(
        "SELECT COUNT(*) FROM job_postings WHERE submitted_at IS NOT NULL AND date(submitted_at)=date('now')"
    ).fetchone()[0]
    return count < cap, f"{count}/{cap} submissions used today"


def _delay_elapsed(conn: sqlite3.Connection, min_seconds: int) -> tuple[bool, str]:
    row = conn.execute(
        "SELECT CAST(strftime('%s','now') AS INTEGER) - CAST(strftime('%s', MAX(submitted_at)) AS INTEGER) "
        "FROM job_postings WHERE submitted_at IS NOT NULL"
    ).fetchone()
    elapsed = row[0]
    if elapsed is None:
        return True, "no previous submission"
    return elapsed >= min_seconds, f"{elapsed}s since last submission (minimum {min_seconds}s)"


def evaluate(conn: sqlite3.Connection, job: sqlite3.Row) -> GateReport:
    report = GateReport()
    automation = load_automation_settings(conn)
    scoring = load_scoring_settings(conn)
    job_id = int(job["id"])

    report.add(
        "mode_autonomous",
        automation.mode == AutomationMode.AUTONOMOUS.value,
        f"active mode is '{automation.mode}'",
    )
    report.add(
        "score_threshold",
        int(job["score"]) >= automation.autonomy_min_score,
        f"score {job['score']} vs threshold {automation.autonomy_min_score}",
    )
    report.add(
        "company_not_blacklisted",
        not is_blacklisted(job["company"], scoring),
        f"company '{job['company']}'",
    )
    report.add(
        "no_duplicate_submission",
        not _duplicate_submission_exists(conn, job),
        "checked submitted rows by company+title and apply_url",
    )
    docs_ok, docs_detail = _documents_ready(conn, job_id)
    report.add("documents_factual", docs_ok, docs_detail)
    answers_ok, answers_detail = _answers_ready(conn, job_id)
    report.add("answers_ready", answers_ok, answers_detail)

    company = str(job["company"]).strip().lower()
    in_scope = (
        job_id in automation.autonomy_job_ids
        or company in automation.autonomy_companies
        or str(job["source"]).strip().lower() in automation.autonomy_ats
        or "*" in automation.autonomy_companies
    )
    report.add(
        "autonomy_scope",
        in_scope,
        "job, company, or ATS is explicitly enabled for autonomous submission" if in_scope
        else "autonomous submission has not been enabled for this job, company, or ATS",
    )
    cap_ok, cap_detail = _within_daily_cap(conn, automation.max_submissions_per_day)
    report.add("daily_cap", cap_ok, cap_detail)
    delay_ok, delay_detail = _delay_elapsed(conn, automation.min_seconds_between_submissions)
    report.add("min_delay", delay_ok, delay_detail)
    return report.finalize()
