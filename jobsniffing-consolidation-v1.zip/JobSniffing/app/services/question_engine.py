"""Classify application questions and resolve answers from approved sources only.

Three classifications:
  safe_auto        — meaning and value both known; automation may submit as-is.
  adapter_rule     — value known, formatting is adapter-specific.
  requires_review  — judgment, ambiguity, or missing/unapproved data; never guessed.

Answers come exclusively from the verified profile or the approved QA bank.
A question that matches nothing, or maps to an unknown/unapproved field, is
always parked for human review.
"""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from difflib import SequenceMatcher

from app.domain.enums import AnswerClassification as C
from app.services.profile_service import DEMOGRAPHICS_POLICY_KEY, resolve_for_automation

QA_MATCH_THRESHOLD = 0.78

# Order matters: sensitive rules run before mapped rules.
_SENSITIVE = [
    (re.compile(r"salary|compensation|pay expectation|wage|hourly rate", re.I), "salary"),
    (re.compile(r"criminal|conviction|offen[cs]e|background check", re.I), "criminal_history"),
    (re.compile(r"security clearance|reliability status|secret clearance", re.I), "clearance"),
    (re.compile(r"disab|accommodat", re.I), "disability"),
    (re.compile(r"conflict of interest", re.I), "conflict_of_interest"),
    (re.compile(r"\breference(s)?\b", re.I), "references"),
]
_DEMOGRAPHICS = re.compile(
    r"gender|ethnic|race|veteran|indigenous|aboriginal|visible minority|self.?identif|sexual orientation", re.I
)
_FREE_FORM = re.compile(
    r"\bwhy\b|describe|tell us|explain|cover letter|what interests you|motivat", re.I
)
_MAPPED: list[tuple[re.Pattern, str, C]] = [
    (re.compile(r"authoriz|work permit|legally (entitled|eligible|able) to work|eligible to work", re.I), "work_authorization", C.SAFE_AUTO),
    (re.compile(r"sponsor", re.I), "sponsorship_required", C.SAFE_AUTO),
    (re.compile(r"willing to relocate|relocat", re.I), "willing_to_relocate", C.SAFE_AUTO),
    (re.compile(r"remote|hybrid|on-?site|work location", re.I), "work_location_preference", C.ADAPTER_RULE),
    (re.compile(r"start date|availab|notice period|when (can|could) you start", re.I), "availability", C.ADAPTER_RULE),
    (re.compile(r"french|english|bilingual|language proficiency|languages", re.I), "languages", C.ADAPTER_RULE),
    (re.compile(r"(city|province|country).*(reside|live|located)|current location|where are you (located|based)", re.I), "location", C.SAFE_AUTO),
    (re.compile(r"shift|weekend|evening|overtime", re.I), "shift_availability", C.ADAPTER_RULE),
    (re.compile(r"years? of experience|experience.*years?|how many years", re.I), "years_experience", C.ADAPTER_RULE),
    (re.compile(r"\bphone\b|telephone", re.I), "phone", C.SAFE_AUTO),
    (re.compile(r"e-?mail", re.I), "email", C.SAFE_AUTO),
]


@dataclass
class AnswerResolution:
    question: str
    answer: str
    classification: C
    source: str
    reason: str = ""


def classify(question: str) -> tuple[str, str | None, C]:
    """Return (category, profile_key, preliminary_classification)."""
    for pattern, category in _SENSITIVE:
        if pattern.search(question):
            return category, None, C.REQUIRES_REVIEW
    if _DEMOGRAPHICS.search(question):
        return "demographics", DEMOGRAPHICS_POLICY_KEY, C.ADAPTER_RULE
    if _FREE_FORM.search(question):
        return "free_form", None, C.REQUIRES_REVIEW
    for pattern, key, classification in _MAPPED:
        if pattern.search(question):
            return key, key, classification
    return "unmapped", None, C.REQUIRES_REVIEW


def _qa_bank_lookup(conn: sqlite3.Connection, question: str) -> tuple[sqlite3.Row | None, float]:
    best, best_score = None, 0.0
    normalized = " ".join(question.lower().split())
    for row in conn.execute("SELECT * FROM qa_answers WHERE approved=1"):
        score = SequenceMatcher(None, normalized, " ".join(str(row["question"]).lower().split())).ratio()
        if score > best_score:
            best, best_score = row, score
    return best, best_score


def resolve(conn: sqlite3.Connection, question: str) -> AnswerResolution:
    category, profile_key, classification = classify(question)
    if classification is C.REQUIRES_REVIEW or profile_key is None:
        match, score = _qa_bank_lookup(conn, question)
        if match is not None and score >= QA_MATCH_THRESHOLD and category == "unmapped":
            conn.execute("UPDATE qa_answers SET usage_count=usage_count+1 WHERE id=?", (match["id"],))
            return AnswerResolution(question, str(match["answer"]), C(str(match["classification"])), f"qa_bank:{match['id']}", f"fuzzy match {score:.2f}")
        return AnswerResolution(question, "", C.REQUIRES_REVIEW, "", f"category '{category}' requires human review")
    value, source = resolve_for_automation(conn, profile_key, context="application")
    if value is None:
        return AnswerResolution(question, "", C.REQUIRES_REVIEW, "", source)
    return AnswerResolution(question, value, classification, source)


def prepare_answers(conn: sqlite3.Connection, job_id: int, questions: list[str]) -> dict:
    counts = {"total": 0, "safe_auto": 0, "adapter_rule": 0, "requires_review": 0}
    for question in questions:
        question = question.strip()
        if not question:
            continue
        resolution = resolve(conn, question)
        conn.execute(
            """
            INSERT INTO application_answers(job_id,question,answer,classification,source)
            VALUES(?,?,?,?,?)
            ON CONFLICT(job_id,question) DO UPDATE SET
              answer=excluded.answer, classification=excluded.classification, source=excluded.source
            """,
            (job_id, question, resolution.answer, resolution.classification.value, resolution.source),
        )
        counts["total"] += 1
        counts[resolution.classification.value] += 1
    return counts


def approve_answer(conn: sqlite3.Connection, job_id: int, question: str, answer: str, remember: bool = False) -> None:
    updated = conn.execute(
        "UPDATE application_answers SET answer=?, approved=1 WHERE job_id=? AND question=?",
        (answer, job_id, question),
    ).rowcount
    if not updated:
        raise KeyError(f"No prepared answer for job {job_id} question {question!r}")
    if remember:
        conn.execute(
            """
            INSERT INTO qa_answers(question,answer,classification,approved)
            VALUES(?,?,?,1)
            ON CONFLICT(question) DO UPDATE SET answer=excluded.answer, approved=1, updated_at=CURRENT_TIMESTAMP
            """,
            (question, answer, C.ADAPTER_RULE.value),
        )


def list_answers(conn: sqlite3.Connection, job_id: int) -> list[sqlite3.Row]:
    return list(conn.execute("SELECT * FROM application_answers WHERE job_id=? ORDER BY id", (job_id,)))
