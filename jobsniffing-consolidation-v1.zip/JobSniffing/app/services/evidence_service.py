from __future__ import annotations

import sqlite3


def add_evidence(conn: sqlite3.Connection, job_id: int, kind: str, content: str = "", path: str = "") -> int:
    cursor = conn.execute(
        "INSERT INTO evidence(job_id,kind,content,path) VALUES(?,?,?,?)",
        (job_id, kind, content[:50_000], path),
    )
    return int(cursor.lastrowid)


def list_evidence(conn: sqlite3.Connection, job_id: int) -> list[sqlite3.Row]:
    return list(conn.execute("SELECT * FROM evidence WHERE job_id=? ORDER BY id", (job_id,)))


def has_evidence(conn: sqlite3.Connection, job_id: int) -> bool:
    return conn.execute("SELECT 1 FROM evidence WHERE job_id=? LIMIT 1", (job_id,)).fetchone() is not None


# Only these kinds prove a submission actually happened. Drafts, screenshots,
# and page snapshots are context, not confirmation.
CONFIRMATION_KINDS = frozenset({
    "manual_confirmation", "confirmation_text", "confirmation_number",
    "confirmation_email", "smtp_message_id",
})


def has_confirmation_evidence(conn: sqlite3.Connection, job_id: int) -> bool:
    placeholders = ",".join("?" * len(CONFIRMATION_KINDS))
    row = conn.execute(
        f"SELECT 1 FROM evidence WHERE job_id=? AND kind IN ({placeholders}) LIMIT 1",
        (job_id, *CONFIRMATION_KINDS),
    ).fetchone()
    return row is not None
