"""Verified candidate profile: the only approved source for application answers.

Every field carries value, source, verification status, allowed usage
contexts, and explicit automation permissions. Unknown information stays
unknown — nothing here ever infers a value. Sensitive keys are structurally
locked to manual approval regardless of what the caller passes.
"""
from __future__ import annotations

import json
import re
import sqlite3

VERIFICATIONS = {"verified", "unverified", "unknown"}

# Standing exception, explicitly configured by the user: a single default for
# voluntary self-identification questions (e.g. "Prefer not to answer").
DEMOGRAPHICS_POLICY_KEY = "demographics_default"

_SENSITIVE_KEY_PATTERNS = [
    re.compile(p) for p in (
        r"salary", r"compensation", r"criminal", r"conviction", r"disab",
        r"demograph", r"gender", r"ethnic", r"clearance", r"conflict",
        r"reference", r"legal_declaration",
    )
]


def is_sensitive_key(key: str) -> bool:
    if key == DEMOGRAPHICS_POLICY_KEY:
        return False
    return any(p.search(key) for p in _SENSITIVE_KEY_PATTERNS)


def upsert_field(
    conn: sqlite3.Connection,
    key: str,
    value: str,
    *,
    source: str = "user",
    verification: str = "unverified",
    allowed_contexts: list[str] | None = None,
    automation_may_submit: bool = False,
    requires_manual_approval: bool = True,
) -> None:
    key = key.strip().lower().replace(" ", "_")
    if not key:
        raise ValueError("profile field key is required")
    if verification not in VERIFICATIONS:
        raise ValueError(f"verification must be one of {sorted(VERIFICATIONS)}")
    if is_sensitive_key(key):
        automation_may_submit = False
        requires_manual_approval = True
    conn.execute(
        """
        INSERT INTO profile_fields(key,value,source,verification,allowed_contexts,automation_may_submit,requires_manual_approval)
        VALUES(?,?,?,?,?,?,?)
        ON CONFLICT(key) DO UPDATE SET
          value=excluded.value, source=excluded.source, verification=excluded.verification,
          allowed_contexts=excluded.allowed_contexts,
          automation_may_submit=excluded.automation_may_submit,
          requires_manual_approval=excluded.requires_manual_approval,
          updated_at=CURRENT_TIMESTAMP
        """,
        (
            key, value, source, verification,
            json.dumps(allowed_contexts or ["application", "documents"]),
            int(automation_may_submit), int(requires_manual_approval),
        ),
    )


def get_field(conn: sqlite3.Connection, key: str) -> dict | None:
    row = conn.execute("SELECT * FROM profile_fields WHERE key=?", (key,)).fetchone()
    if row is None:
        return None
    field = dict(row)
    field["allowed_contexts"] = json.loads(field["allowed_contexts"])
    return field


def list_fields(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute("SELECT * FROM profile_fields ORDER BY key").fetchall()
    result = []
    for row in rows:
        field = dict(row)
        field["allowed_contexts"] = json.loads(field["allowed_contexts"])
        result.append(field)
    return result


def resolve_for_automation(conn: sqlite3.Connection, key: str, context: str) -> tuple[str | None, str]:
    """Return (value, reason). value is None whenever automation may not use it."""
    field = get_field(conn, key)
    if field is None:
        return None, f"profile field '{key}' is unknown"
    if field["verification"] != "verified":
        return None, f"profile field '{key}' is not verified"
    if field["requires_manual_approval"]:
        return None, f"profile field '{key}' always requires manual approval"
    if not field["automation_may_submit"]:
        return None, f"profile field '{key}' is not approved for automated submission"
    contexts = field["allowed_contexts"]
    if context not in contexts and "*" not in contexts:
        return None, f"profile field '{key}' is not allowed in context '{context}'"
    return str(field["value"]), f"profile:{key}"
