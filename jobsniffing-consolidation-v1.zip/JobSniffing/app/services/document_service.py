"""Résumé and cover-letter pipeline with structural factuality guarantees.

The master résumé is a set of identified facts. Tailoring may reorder,
emphasize, and select — it can never introduce text that is not an exact,
id-tracked master fact. `verify_variant` re-checks that invariant on the
final artifact, so a passing factuality report is evidence, not a promise.
"""
from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path

from app.config import resolve_project_path
from app.services.profile_service import get_field
from app.services.settings_service import load_scoring_settings

MASTER_KIND = "master_resume"
VARIANT_KIND = "resume_variant"
COVER_KIND = "cover_letter"
MAX_BULLETS_PER_ROLE = 6

_EXAGGERATION = re.compile(
    r"\b(expert|world[- ]class|best[- ]in[- ]class|guru|ninja|rockstar|unparalleled|10x|visionary)\b", re.I
)

_LIST_SECTIONS = ("skills", "education", "certifications", "languages")


def _validate_master(content: dict) -> None:
    if not isinstance(content, dict):
        raise ValueError("master resume must be an object")
    seen: set[str] = set()

    def check_fact(item: dict, where: str, text_key: str) -> None:
        fact_id, text = item.get("id"), item.get(text_key, "")
        if not fact_id or not str(text).strip():
            raise ValueError(f"every {where} entry needs a non-empty 'id' and '{text_key}'")
        if fact_id in seen:
            raise ValueError(f"duplicate fact id '{fact_id}'")
        seen.add(fact_id)

    for role in content.get("experience", []):
        if not role.get("company") or not role.get("title"):
            raise ValueError("every experience entry needs 'company' and 'title'")
        for bullet in role.get("bullets", []):
            check_fact(bullet, "experience bullet", "text")
    for section in _LIST_SECTIONS:
        key = "name" if section == "skills" else "text"
        for item in content.get(section, []):
            check_fact(item, section, key)


def save_master(conn: sqlite3.Connection, content: dict) -> int:
    _validate_master(content)
    version = 1 + (conn.execute(
        "SELECT COALESCE(MAX(version),0) FROM documents WHERE kind=? AND job_id IS NULL", (MASTER_KIND,)
    ).fetchone()[0])
    conn.execute(
        "INSERT INTO documents(job_id,kind,version,content,factuality,factuality_passed) VALUES(NULL,?,?,?,?,1)",
        (MASTER_KIND, version, json.dumps(content, ensure_ascii=False), "{}"),
    )
    return version


def load_master(conn: sqlite3.Connection) -> dict | None:
    row = conn.execute(
        "SELECT content FROM documents WHERE kind=? AND job_id IS NULL ORDER BY version DESC LIMIT 1", (MASTER_KIND,)
    ).fetchone()
    return json.loads(row["content"]) if row else None


def _fact_index(master: dict) -> dict[str, str]:
    facts: dict[str, str] = {}
    for role in master.get("experience", []):
        for bullet in role.get("bullets", []):
            facts[bullet["id"]] = bullet["text"]
    for section in _LIST_SECTIONS:
        key = "name" if section == "skills" else "text"
        for item in master.get(section, []):
            facts[item["id"]] = item[key]
    return facts


def _jd_keywords(conn: sqlite3.Connection, master: dict, description: str) -> tuple[list[str], dict[str, int]]:
    text = description.lower()
    weights = load_scoring_settings(conn).preferred_terms
    present = {term: weight for term, weight in weights.items() if term in text}
    skill_terms = {
        str(item["name"]).lower() for item in master.get("skills", []) if str(item["name"]).lower() in text
    }
    ordered = sorted(present, key=lambda t: -present[t]) + sorted(skill_terms - set(present))
    return ordered, present


def _matches(text: str, keywords: list[str]) -> list[str]:
    lowered = text.lower()
    return [k for k in keywords if k in lowered]


def verify_variant(master: dict, variant: dict) -> list[str]:
    """Return every variant line whose (id, text) pair is not an exact master fact."""
    facts = _fact_index(master)
    offenders: list[str] = []

    def check(item: dict, text_key: str) -> None:
        if facts.get(item.get("id")) != item.get(text_key):
            offenders.append(str(item.get(text_key, ""))[:200])

    for role in variant.get("experience", []):
        for bullet in role.get("bullets", []):
            check(bullet, "text")
    for section in _LIST_SECTIONS:
        key = "name" if section == "skills" else "text"
        for item in variant.get(section, []):
            check(item, key)
    if variant.get("summary", "") != master.get("summary", ""):
        offenders.append("summary differs from master")
    return offenders


def tailor(conn: sqlite3.Connection, job_id: int) -> dict:
    master = load_master(conn)
    if master is None:
        raise ValueError("No master resume stored. Save one at PUT /api/documents/master first.")
    job = conn.execute("SELECT * FROM job_postings WHERE id=?", (job_id,)).fetchone()
    if job is None:
        raise KeyError(f"Unknown job id {job_id}")

    keywords, present_weights = _jd_keywords(conn, master, str(job["description"]) + " " + str(job["title"]))
    used_facts: list[dict] = []
    matched: set[str] = set()

    variant: dict = {"summary": master.get("summary", ""), "experience": []}
    for role in master.get("experience", []):
        scored = []
        for order, bullet in enumerate(role.get("bullets", [])):
            hits = _matches(bullet["text"], keywords)
            scored.append((-len(hits), order, bullet, hits))
        scored.sort()
        kept = []
        for _, _, bullet, hits in scored[:MAX_BULLETS_PER_ROLE]:
            kept.append(dict(bullet))
            used_facts.append({"id": bullet["id"], "text": bullet["text"]})
            matched.update(hits)
        variant["experience"].append({**{k: v for k, v in role.items() if k != "bullets"}, "bullets": kept})
    for section in _LIST_SECTIONS:
        key = "name" if section == "skills" else "text"
        items = list(master.get(section, []))
        items.sort(key=lambda item: (0 if _matches(item[key], keywords) else 1))
        variant[section] = items
        for item in items:
            used_facts.append({"id": item["id"], "text": item[key]})
            matched.update(_matches(item[key], keywords))

    offenders = verify_variant(master, variant)
    supported_weight = sum(w for t, w in present_weights.items() if t in matched)
    total_weight = sum(present_weights.values()) or 1
    exaggerations = sorted({m.group(0).lower() for f in used_facts for m in _EXAGGERATION.finditer(f["text"])})
    all_text = " ".join(f["text"] for f in used_facts) + variant["summary"]
    report = {
        "source_facts": used_facts,
        "keywords_matched": sorted(matched),
        "keywords_excluded": [
            {"keyword": t, "reason": "no verified master-resume evidence; intentionally not added"}
            for t in keywords if t not in matched
        ],
        "exaggeration_risks": exaggerations,
        "lines_without_source": offenders,
        "estimated_pages": max(1, round(len(all_text) / 2800, 1)),
        "doc_score": round(100 * supported_weight / total_weight),
        "rationale": (
            f"Reordered evidence for '{job['title']}' at {job['company']}: "
            f"{len(matched)} of {len(keywords)} posting keywords are backed by master facts."
        ),
    }
    version = 1 + (conn.execute(
        "SELECT COALESCE(MAX(version),0) FROM documents WHERE kind=? AND job_id=?", (VARIANT_KIND, job_id)
    ).fetchone()[0])
    conn.execute(
        "INSERT INTO documents(job_id,kind,version,content,factuality,factuality_passed) VALUES(?,?,?,?,?,?)",
        (job_id, VARIANT_KIND, version, json.dumps(variant, ensure_ascii=False),
         json.dumps(report, ensure_ascii=False), int(not offenders)),
    )
    return {"variant": variant, "factuality": report, "version": version}


def build_cover_letter(conn: sqlite3.Connection, job_id: int) -> dict:
    master = load_master(conn)
    if master is None:
        raise ValueError("No master resume stored.")
    job = conn.execute("SELECT * FROM job_postings WHERE id=?", (job_id,)).fetchone()
    if job is None:
        raise KeyError(f"Unknown job id {job_id}")
    keywords, _ = _jd_keywords(conn, master, str(job["description"]) + " " + str(job["title"]))
    facts = []
    for role in master.get("experience", []):
        for bullet in role.get("bullets", []):
            hits = _matches(bullet["text"], keywords)
            if hits:
                facts.append((len(hits), bullet))
    facts.sort(key=lambda pair: -pair[0])
    top = [bullet for _, bullet in facts[:3]]

    name_field = get_field(conn, "preferred_name") or get_field(conn, "legal_name")
    name = str(name_field["value"]) if name_field else "[Your name]"
    languages = " ".join(str(i.get("text", "")) for i in master.get("languages", [])).lower()
    bilingual_line = (
        " I work comfortably in both English and French." if "french" in languages else ""
    )
    body_lines = [
        f"Dear Hiring Team at {job['company']},",
        "",
        f"I am applying for the {job['title']} position. My directly relevant, verifiable experience includes:",
        *[f"- {bullet['text']}" for bullet in top],
        "",
        f"These are drawn from my attached resume and can each be discussed in detail.{bilingual_line}",
        "",
        "Thank you for your consideration.",
        name,
    ]
    text = "\n".join(body_lines)
    report = {
        "source_facts": [{"id": b["id"], "text": b["text"]} for b in top],
        "placeholders": [] if name_field else ["signature name is unknown; placeholder used"],
        "lines_without_source": [],
    }
    passed = int(bool(top) and not report["placeholders"])
    version = 1 + (conn.execute(
        "SELECT COALESCE(MAX(version),0) FROM documents WHERE kind=? AND job_id=?", (COVER_KIND, job_id)
    ).fetchone()[0])
    conn.execute(
        "INSERT INTO documents(job_id,kind,version,content,factuality,factuality_passed) VALUES(?,?,?,?,?,?)",
        (job_id, COVER_KIND, version, text, json.dumps(report, ensure_ascii=False), passed),
    )
    return {"text": text, "factuality": report, "version": version, "factuality_passed": bool(passed)}


def latest_document(conn: sqlite3.Connection, job_id: int | None, kind: str) -> sqlite3.Row | None:
    if job_id is None:
        return conn.execute(
            "SELECT * FROM documents WHERE kind=? AND job_id IS NULL ORDER BY version DESC LIMIT 1", (kind,)
        ).fetchone()
    return conn.execute(
        "SELECT * FROM documents WHERE kind=? AND job_id=? ORDER BY version DESC LIMIT 1", (kind, job_id)
    ).fetchone()


def document_output_dir(job_id: int) -> Path:
    directory = resolve_project_path(f"data/documents/{job_id}")
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def attach_pdf(conn: sqlite3.Connection, document_id: int, pdf_path: str) -> None:
    conn.execute("UPDATE documents SET pdf_path=? WHERE id=?", (pdf_path, document_id))


def _document_contact(conn: sqlite3.Connection) -> dict[str, str]:
    from app.services.profile_service import resolve_for_automation

    contact: dict[str, str] = {}
    name_field = get_field(conn, "preferred_name") or get_field(conn, "legal_name")
    if name_field:
        contact["name"] = str(name_field["value"])
    for key in ("email", "phone", "location"):
        value, _ = resolve_for_automation(conn, key, context="documents")
        if value:
            contact[key] = value
    return contact


def ensure_variant_pdf(conn: sqlite3.Connection, job_id: int) -> str | None:
    """Render (once) and return the PDF path for the latest resume variant."""
    from app.services.render_pdf import cover_letter_pdf, resume_pdf

    row = latest_document(conn, job_id, VARIANT_KIND)
    if row is None:
        return None
    if row["pdf_path"] and Path(row["pdf_path"]).exists():
        return str(row["pdf_path"])
    contact = _document_contact(conn)
    out = document_output_dir(job_id) / f"resume_v{row['version']}.pdf"
    resume_pdf(json.loads(row["content"]), contact, out)
    attach_pdf(conn, int(row["id"]), str(out))
    cover = latest_document(conn, job_id, COVER_KIND)
    if cover is not None and not cover["pdf_path"]:
        cover_out = document_output_dir(job_id) / f"cover_v{cover['version']}.pdf"
        cover_letter_pdf(str(cover["content"]), contact, cover_out)
        attach_pdf(conn, int(cover["id"]), str(cover_out))
    return str(out)
