"""Submission adapter contract.

CRITICAL rule (inherited from HunterXJob and enforced again by the
orchestrator): an adapter must NEVER return result="submitted" unless it
observed credible confirmation and attached it as evidence. When in doubt,
return "awaiting_confirmation" or "manual_intervention" — never guess.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Protocol

AdapterResult = Literal["submitted", "awaiting_confirmation", "manual_intervention", "failed"]

# Evidence kinds that count as submission confirmation (see evidence_service).
LIVE_ENV_FLAG = "JOBSNIFFING_ALLOW_LIVE_SUBMISSION"


@dataclass
class AdapterInput:
    job: dict
    contact: dict[str, str]
    answers: list[dict] = field(default_factory=list)
    resume_pdf: str | None = None
    cover_letter: str = ""
    to_email: str | None = None
    live: bool = False


@dataclass
class AdapterOutcome:
    result: AdapterResult
    message: str = ""
    evidence: list[tuple[str, str]] = field(default_factory=list)
    screenshots: list[str] = field(default_factory=list)


class SubmitAdapter(Protocol):
    name: str

    def run(self, ctx: AdapterInput) -> AdapterOutcome: ...
