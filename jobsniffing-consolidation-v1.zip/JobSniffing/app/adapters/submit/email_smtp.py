"""Tier-0 submission channel: direct email with attachments over SMTP.

Termux-native (stdlib only). Live sending requires BOTH the per-call
live=True flag and the JOBSNIFFING_ALLOW_LIVE_SUBMISSION=1 environment gate;
the environment gate cannot be toggled from the API or dashboard.
For email, credible confirmation = the SMTP server accepted the message;
the Message-ID plus a full RFC-822 copy are stored as evidence.
"""
from __future__ import annotations

import os
import smtplib
from email.message import EmailMessage
from email.utils import make_msgid
from pathlib import Path

from app.adapters.submit.base import LIVE_ENV_FLAG, AdapterInput, AdapterOutcome


class EmailSmtpAdapter:
    name = "email"

    def run(self, ctx: AdapterInput) -> AdapterOutcome:
        if not ctx.to_email or "@" not in ctx.to_email:
            return AdapterOutcome("manual_intervention", "no destination email address was provided")
        resume = Path(ctx.resume_pdf) if ctx.resume_pdf else None
        if resume is None or not resume.exists():
            return AdapterOutcome("manual_intervention", "resume PDF is missing; prepare documents first")

        message = EmailMessage()
        title, company = ctx.job.get("title", "the role"), ctx.job.get("company", "")
        message["Subject"] = f"Application for {title}" + (f" at {company}" if company else "")
        message["To"] = ctx.to_email
        message["From"] = os.getenv("SMTP_FROM_ADDRESS") or os.getenv("SMTP_USERNAME", "")
        message["Message-ID"] = make_msgid()
        message.set_content(ctx.cover_letter or "Please find my application attached.")
        message.add_attachment(resume.read_bytes(), maintype="application", subtype="pdf", filename="resume.pdf")

        if not ctx.live or os.getenv(LIVE_ENV_FLAG, "0") != "1":
            return AdapterOutcome(
                "manual_intervention",
                f"dry run: application email to {ctx.to_email} prepared but NOT sent "
                f"(set {LIVE_ENV_FLAG}=1 and pass live=true to send)",
                evidence=[("email_draft", str(message)[:20_000])],
            )

        host, port = os.getenv("SMTP_HOST", ""), int(os.getenv("SMTP_PORT", "587"))
        username, password = os.getenv("SMTP_USERNAME", ""), os.getenv("SMTP_PASSWORD", "")
        if not host or not username or not password:
            return AdapterOutcome("failed", "SMTP is not configured (SMTP_HOST/SMTP_USERNAME/SMTP_PASSWORD)")
        try:
            use_tls = os.getenv("SMTP_USE_TLS", "1") == "1"
            if use_tls:
                with smtplib.SMTP(host, port, timeout=30) as server:
                    server.starttls()
                    server.login(username, password)
                    server.send_message(message)
            else:
                with smtplib.SMTP_SSL(host, port, timeout=30) as server:
                    server.login(username, password)
                    server.send_message(message)
        except Exception as exc:  # noqa: BLE001 — any transport failure is a clean "failed"
            return AdapterOutcome("failed", f"SMTP send failed: {exc}")
        return AdapterOutcome(
            "submitted",
            f"application emailed to {ctx.to_email}",
            evidence=[
                ("smtp_message_id", str(message["Message-ID"])),
                ("email_copy", str(message)[:20_000]),
            ],
        )
