"""Tier-2 Greenhouse form adapter (ported from HunterXJob).

Requires the optional [automation] extra (Playwright + Chromium inside the
Ubuntu proot, never bare Termux). Design rules:

  * Fail closed: anything ambiguous ends in manual_intervention, not a guess.
  * CAPTCHA / anti-bot walls are detected and handed to the human. They are
    never solved, bypassed, or retried.
  * "submitted" is returned only when a confirmation phrase is observed on
    the page, and that phrase + final URL are attached as evidence.
  * All page logic lives in `_run_on_page`, which takes any Page-shaped
    object so the test suite can exercise it without a real browser.
"""
from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Any

from app.adapters.submit.base import LIVE_ENV_FLAG, AdapterInput, AdapterOutcome
from app.config import resolve_project_path

CONFIRMATION_KEYWORDS = [
    "thank you for applying",
    "application has been submitted",
    "we have received your application",
    "your application was received",
    "application received",
]
BLOCK_KEYWORDS = ["captcha", "verify you are human", "are you a robot", "hcaptcha", "recaptcha", "cloudflare"]
FORM_ERROR_KEYWORDS = ["is required", "please complete", "field is required", "required field"]

_EMAIL_SELECTORS = ["#email", "input[type='email']", "input[name*='email']", "input[autocomplete='email']"]
_FIRST_NAME_SELECTORS = ["#first_name", "input[name*='first_name']", "input[autocomplete='given-name']"]
_LAST_NAME_SELECTORS = ["#last_name", "input[name*='last_name']", "input[autocomplete='family-name']"]
_PHONE_SELECTORS = ["#phone", "input[type='tel']", "input[name*='phone']", "input[autocomplete='tel']"]
_RESUME_SELECTORS = [
    "#resume", "input[type='file'][name*='resume']", "input[type='file'][id*='resume']",
    "input[type='file'][aria-label*='resume' i]",
]
_COVER_SELECTORS = ["#cover_letter_text", "textarea[name*='cover_letter']", "textarea[id*='cover_letter']"]
_SUBMIT_SELECTORS = ["#submit_app", "button[type='submit']", "input[type='submit']", "button:has-text('Submit Application')"]


def _count(scope: Any, selector: str) -> int:
    try:
        return int(scope.locator(selector).count())
    except Exception:  # noqa: BLE001
        return 0


def _scopes(page: Any) -> list[Any]:
    scopes = [page]
    try:
        main = getattr(page, "main_frame", None)
        scopes += [f for f in list(page.frames) if f is not main]
    except Exception:  # noqa: BLE001
        pass
    return scopes


def _resume_selector(scope: Any) -> str | None:
    for selector in _RESUME_SELECTORS:
        if _count(scope, selector) > 0:
            return selector
    # One generic file input is unambiguous; several means we refuse to guess.
    if _count(scope, "input[type='file']") == 1:
        return "input[type='file']"
    return None


def _find_form_scope(page: Any) -> Any | None:
    for scope in _scopes(page):
        if any(_count(scope, s) for s in _EMAIL_SELECTORS) and _resume_selector(scope):
            return scope
    return None


def _try_fill(scope: Any, selectors: list[str], value: str) -> bool:
    if not value:
        return False
    for selector in selectors:
        try:
            locator = scope.locator(selector).first
            if locator.count() > 0:
                locator.fill(value)
                return True
        except Exception:  # noqa: BLE001
            continue
    return False


def _try_click(scope: Any, selectors: list[str]) -> bool:
    for selector in selectors:
        try:
            locator = scope.locator(selector).first
            if locator.count() > 0:
                locator.click()
                return True
        except Exception:  # noqa: BLE001
            continue
    return False


def _content(page: Any) -> str:
    try:
        return str(page.content()).lower()
    except Exception:  # noqa: BLE001
        return ""


def _keyword_sentence(content: str, keyword: str) -> str:
    text = re.sub(r"<[^>]+>", " ", content)
    for sentence in re.split(r"(?<=[.!?])\s+", text):
        if keyword in sentence:
            return " ".join(sentence.split())[:400]
    return keyword


def _shot(page: Any, directory: Path | None, label: str, shots: list[str]) -> None:
    if directory is None:
        return
    try:
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{int(time.time())}-{label}.png"
        page.screenshot(path=str(path), full_page=True)
        shots.append(str(path))
    except Exception:  # noqa: BLE001
        pass


def _run_on_page(page: Any, ctx: AdapterInput, shots_dir: Path | None = None) -> AdapterOutcome:
    shots: list[str] = []
    content = _content(page)
    for keyword in BLOCK_KEYWORDS:
        if keyword in content:
            _shot(page, shots_dir, "blocked", shots)
            return AdapterOutcome(
                "manual_intervention",
                f"anti-bot check detected ('{keyword}'); finish this application manually",
                screenshots=shots,
            )

    scope = _find_form_scope(page)
    if scope is None:
        _shot(page, shots_dir, "no-form", shots)
        return AdapterOutcome(
            "manual_intervention",
            "could not locate a Greenhouse application form (email + resume upload) on this page",
            screenshots=shots,
        )

    name = ctx.contact.get("name", "").strip()
    first, _, last = name.partition(" ")
    _try_fill(scope, _FIRST_NAME_SELECTORS, first)
    _try_fill(scope, _LAST_NAME_SELECTORS, last or first)
    filled_email = _try_fill(scope, _EMAIL_SELECTORS, ctx.contact.get("email", ""))
    _try_fill(scope, _PHONE_SELECTORS, ctx.contact.get("phone", ""))
    if not filled_email:
        return AdapterOutcome("manual_intervention", "email address is unknown or the email field could not be filled")

    resume_selector = _resume_selector(scope)
    try:
        scope.locator(resume_selector).first.set_input_files(str(ctx.resume_pdf))
    except Exception as exc:  # noqa: BLE001
        return AdapterOutcome("manual_intervention", f"could not attach resume: {exc}")
    _try_fill(scope, _COVER_SELECTORS, ctx.cover_letter)
    _shot(page, shots_dir, "filled", shots)

    if not _try_click(scope, _SUBMIT_SELECTORS):
        return AdapterOutcome("manual_intervention", "no submit button found; review the form manually", screenshots=shots)
    try:
        page.wait_for_timeout(1500)
    except Exception:  # noqa: BLE001
        pass

    after = _content(page)
    _shot(page, shots_dir, "after-submit", shots)
    for keyword in BLOCK_KEYWORDS:
        if keyword in after:
            return AdapterOutcome(
                "manual_intervention",
                f"anti-bot check appeared after submit ('{keyword}'); confirm manually",
                screenshots=shots,
            )
    for keyword in CONFIRMATION_KEYWORDS:
        if keyword in after:
            return AdapterOutcome(
                "submitted",
                "confirmation text observed after submit",
                evidence=[
                    ("confirmation_text", _keyword_sentence(after, keyword)),
                    ("final_url", str(getattr(page, "url", ""))),
                ],
                screenshots=shots,
            )
    for keyword in FORM_ERROR_KEYWORDS:
        if keyword in after:
            return AdapterOutcome(
                "manual_intervention",
                "the form reported missing required fields the adapter does not know how to answer",
                screenshots=shots,
            )
    return AdapterOutcome(
        "awaiting_confirmation",
        "form submitted but no confirmation text observed; verify before treating as submitted",
        screenshots=shots,
    )


class GreenhousePlaywrightAdapter:
    name = "greenhouse"

    def run(self, ctx: AdapterInput) -> AdapterOutcome:
        if not ctx.live or os.getenv(LIVE_ENV_FLAG, "0") != "1":
            return AdapterOutcome(
                "manual_intervention",
                f"dry run: browser adapter not launched (set {LIVE_ENV_FLAG}=1 and pass live=true)",
            )
        if not ctx.resume_pdf or not Path(ctx.resume_pdf).exists():
            return AdapterOutcome("manual_intervention", "resume PDF is missing; prepare documents first")
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            return AdapterOutcome(
                "failed",
                "Playwright is not installed. Run: pip install 'jobsniffing[automation]' && playwright install chromium",
            )
        shots_dir = resolve_project_path(f"data/screenshots/{ctx.job.get('id', 'unknown')}")
        try:
            with sync_playwright() as pw:
                browser = pw.chromium.launch(headless=True)
                page = browser.new_page()
                page.goto(str(ctx.job.get("apply_url", "")), wait_until="domcontentloaded")
                outcome = _run_on_page(page, ctx, shots_dir)
                browser.close()
                return outcome
        except Exception as exc:  # noqa: BLE001
            return AdapterOutcome("failed", f"browser automation failed: {exc}")
