from app.domain.enums import ApplicationStatus as S, TERMINAL_STATUSES

# Superset of the 0.2.0 machine: every previously allowed transition remains
# valid, and the full preparation/verification pipeline from the consolidation
# spec is added. `submitted` is reachable only through evidence-checked code
# paths (see tracking_service.change_status).
ALLOWED_TRANSITIONS: dict[S, set[S]] = {
    S.DISCOVERED: {S.SCORED, S.BLOCKED},
    S.SCORED: {S.SHORTLISTED, S.REJECTED, S.NEEDS_REVIEW, S.BLOCKED},
    S.REJECTED: {S.SHORTLISTED, S.CLOSED},
    S.SHORTLISTED: {S.DOCUMENTS_PREPARED, S.APPROVED, S.NEEDS_REVIEW, S.BLOCKED, S.WITHDRAWN},
    S.DOCUMENTS_PREPARED: {S.ANSWERS_PREPARED, S.NEEDS_REVIEW, S.BLOCKED, S.WITHDRAWN},
    S.ANSWERS_PREPARED: {S.READY_FOR_REVIEW, S.NEEDS_REVIEW, S.BLOCKED, S.WITHDRAWN},
    S.READY_FOR_REVIEW: {S.APPROVED, S.NEEDS_REVIEW, S.BLOCKED, S.WITHDRAWN, S.CLOSED},
    S.APPROVED: {S.QUEUED, S.BLOCKED, S.WITHDRAWN},
    S.QUEUED: {S.FILLING, S.NEEDS_REVIEW, S.BLOCKED, S.WITHDRAWN},
    S.FILLING: {
        S.AWAITING_CONFIRMATION, S.SUBMITTED, S.MANUAL_INTERVENTION_REQUIRED,
        S.NEEDS_REVIEW, S.BLOCKED, S.FAILED,
    },
    S.AWAITING_CONFIRMATION: {S.SUBMITTED, S.VERIFICATION_FAILED, S.MANUAL_INTERVENTION_REQUIRED},
    S.VERIFICATION_FAILED: {S.MANUAL_INTERVENTION_REQUIRED, S.QUEUED, S.FAILED, S.CLOSED},
    S.MANUAL_INTERVENTION_REQUIRED: {S.QUEUED, S.SUBMITTED, S.FAILED, S.WITHDRAWN, S.CLOSED},
    S.NEEDS_REVIEW: {S.SHORTLISTED, S.APPROVED, S.QUEUED, S.BLOCKED, S.FAILED, S.WITHDRAWN, S.CLOSED},
    S.SUBMITTED: set(),
    S.BLOCKED: set(),
    S.WITHDRAWN: set(),
    S.CLOSED: set(),
    S.FAILED: {S.NEEDS_REVIEW},
}

# Statuses that rescoring/blacklisting must never overwrite: terminal records
# plus anything an adapter may currently be acting on.
PROTECTED_FROM_RESCORE = TERMINAL_STATUSES | {
    S.FILLING, S.AWAITING_CONFIRMATION, S.MANUAL_INTERVENTION_REQUIRED,
}


def can_transition(current: S, target: S) -> bool:
    return current == target or target in ALLOWED_TRANSITIONS[current]


def assert_transition(current: S, target: S) -> None:
    if not can_transition(current, target):
        raise ValueError(f"Invalid application status transition: {current.value} -> {target.value}")


def is_terminal(status: S) -> bool:
    return status in TERMINAL_STATUSES
