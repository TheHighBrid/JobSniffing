from enum import StrEnum


class ApplicationStatus(StrEnum):
    DISCOVERED = "discovered"
    SCORED = "scored"
    REJECTED = "rejected"
    SHORTLISTED = "shortlisted"
    DOCUMENTS_PREPARED = "documents_prepared"
    ANSWERS_PREPARED = "answers_prepared"
    READY_FOR_REVIEW = "ready_for_review"
    APPROVED = "approved"
    QUEUED = "queued"
    FILLING = "filling"
    AWAITING_CONFIRMATION = "awaiting_confirmation"
    SUBMITTED = "submitted"
    VERIFICATION_FAILED = "verification_failed"
    MANUAL_INTERVENTION_REQUIRED = "manual_intervention_required"
    NEEDS_REVIEW = "needs_review"
    BLOCKED = "blocked"
    FAILED = "failed"
    WITHDRAWN = "withdrawn"
    CLOSED = "closed"


TERMINAL_STATUSES = {
    ApplicationStatus.SUBMITTED,
    ApplicationStatus.BLOCKED,
    ApplicationStatus.WITHDRAWN,
    ApplicationStatus.CLOSED,
}


class AutomationMode(StrEnum):
    DISCOVERY_ONLY = "discovery_only"
    PREPARE_ONLY = "prepare_only"
    AUTONOMOUS = "autonomous"


class AnswerClassification(StrEnum):
    SAFE_AUTO = "safe_auto"
    ADAPTER_RULE = "adapter_rule"
    REQUIRES_REVIEW = "requires_review"
