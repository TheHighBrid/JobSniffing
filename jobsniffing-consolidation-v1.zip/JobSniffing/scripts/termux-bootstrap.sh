#!/usr/bin/env sh
set -eu
if ! command -v pkg >/dev/null 2>&1; then echo "Use ./scripts/ubuntu-bootstrap.sh inside Ubuntu/proot." >&2; exit 1; fi
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
pkg update -y
pkg install -y python git rust clang make pkg-config
cd "$ROOT"
python -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e '.[test]'
./scripts/verify.sh
echo "Ready. Run ./scripts/termux-run.sh"
